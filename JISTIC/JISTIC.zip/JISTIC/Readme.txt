Prerequisites:

Java 5.0 or greater (http://www.java.com).   Version 6.0 or greater is recommended if available for your platform.

Contents:
- UserGuide.pdf: user manual for the tool
- JISTIC.jar : Application compiled for Java 1.6 , if using 5.0 recompile the source code
- src.zip: source code
- hg18_Gene_Info.txt: Human gene locations file (hg18)
- hg18_miRNA_Info.txt: Human miRNA locations file (hg18)
- Human_cytoBand.txt: chomosomal bands (hg18)
- /Matlab: Folder that contains Matlab scripts used for plots and statistics.
	   Look at exampleJistic.m for example of use.
- /glioexample: Folder that contains the files necessary to run JISTIC on the TCGA Glioblastoma Dataset

1)Gene, miRNA locations and chromosomal bands were downloaded from UCSC
http://nar.oxfordjournals.org/cgi/content/full/38/suppl_1/D613