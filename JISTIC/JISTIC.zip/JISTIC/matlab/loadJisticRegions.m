function [ result ] = loadJisticRegions( regionsfile )
 %loadJisticRegions return parse regions in file
    % result{:}.type
    % result{:}.chrom
    % result{:}.start
    % result{:}.end
    % result{:}.qval


    fidr=fopen(regionsfile);
    fgetl(fidr);
    %region	qvalue
    %AMP:chr1:554317(1p36:33)	0.10170764579637906
    %AMP:chr1:554317-554467(1p36:33)	0.10170764579637906
    regionsdata= textscan(fidr,'%3s:chr%d:%[^()](%[^()]) %f' ,'delimiter','\t');  

    
    result.type=regionsdata{1};
    result.chrom=regionsdata{2};
    result.qval=regionsdata{5};
    result.start=zeros(length(regionsdata{1}),1);
    result.end=zeros(length(regionsdata{1}),1);
        
    for k = 1:length(regionsdata{1})                        
        % get start location 
        a=str2num(regexprep(regionsdata{3}{k}, '-', ';'));
        result.start(k)=a(1);
        % if end location exists, get end, otherwise set start
        if size(a,1)==2
            result.end(k)=a(2);
        else
            result.end(k)=a(1);
        end                 
    end
    fclose(fidr);