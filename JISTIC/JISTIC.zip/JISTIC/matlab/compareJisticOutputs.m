function compareJisticOutputs( markerdata , peaksdata , regionsdata , desiredchromosome , ampordel, abthres, fignum,desiredregion)
%compareJisticOutputs compare statistics from 2 outputs of Jistic
%  compareJisticOutputs( mds , pds , rds , dc , aod, abt, fgn, dr) 
%             compare JISTIC relevant statistics for aberrations of type 
%             ampordel (0=AMP,1=DEL) in region dr for chromosome dc (dc=-1 
%             for all chromosomes)
%             mds,pds and rds: cell arrays with two elements containing the
%             data obtained from loadJisticData
%             dc: chromosome to plot (-1 if all)
%             aod: type of aberration (0=AMP,1=DEL)
%             abt: threshold for the Q value
%             fgn: the number of the first figure to plot
%             dr: region to plot.if not set, it takes the whole chromosome


display('*** Peak comparison ***');
if(nargin==7) 
    unionmarkerchrom=[markerdata{1}.chrom ; markerdata{2}.chrom];
    unionmarkerdataloc=[markerdata{1}.loc ; markerdata{2}.loc];
    if desiredchromosome==-1        
        desiredregion=[0 max(unionmarkerdataloc)];
    else
        indexesmda=find(unionmarkerchrom==desiredchromosome);
        desiredregion=[0 max(unionmarkerdataloc(indexesmda))];
    end
end

if ampordel==0
    destype='AMP';
else
    destype='DEL';
end

for k=[1:2]
    if desiredchromosome==-1
        indexespd{k}=find(strcmp(peaksdata{k}.type, destype) & ( ...
            (peaksdata{k}.start>=desiredregion(1) & peaksdata{k}.start<=desiredregion(2)) | ...
            (peaksdata{k}.end>=desiredregion(1) & peaksdata{k}.end<=desiredregion(2)) ) );
    else
        indexespd{k}=find(peaksdata{k}.chrom==desiredchromosome & strcmp(peaksdata{k}.type, destype) & ( ...
            (peaksdata{k}.start>=desiredregion(1) & peaksdata{k}.start<=desiredregion(2)) | ...
            (peaksdata{k}.end>=desiredregion(1) & peaksdata{k}.end<=desiredregion(2)) ) );
    end
    
    numpeaks{k}=size(indexespd{k},1);
    display(['Dataset ' num2str(k) '. Number of peaks: ' num2str(numpeaks{k})]);
    numbroadpeaks=size(find(peaksdata{k}.broad(indexespd{k})),1);
    display(['Dataset ' num2str(k) '. Number of broad peaks: ' num2str(numbroadpeaks)]);
    numfocalpeaks=size(find(peaksdata{k}.focal(indexespd{k})),1);
    display(['Dataset ' num2str(k) '. Number of focal peaks: ' num2str(numfocalpeaks)]);
            
    if desiredchromosome>-1 & fignum >-1                
        plotJistic( markerdata , peaksdata, regionsdata , desiredchromosome , ampordel, abthres, fignum,0,0,desiredregion);                            
    end
end

chromolist=unique([peaksdata{1}.chrom(indexespd{1}) ; peaksdata{2}.chrom(indexespd{2})]);
numchrom=size(chromolist,1);

newpeaks=zeros(2,1);
for chridx=[1:numchrom]
    chrom=chromolist(chridx,1);
    for k=[1:2]
        indexespd{k}=find(peaksdata{k}.chrom==chrom & strcmp(peaksdata{k}.type, destype) & ( ...
            (peaksdata{k}.start>=desiredregion(1) & peaksdata{k}.start<=desiredregion(2)) | ...
            (peaksdata{k}.end>=desiredregion(1) & peaksdata{k}.end<=desiredregion(2)) ) );
        psc{k}=peaksdata{k}.start(indexespd{k});
        pec{k}=peaksdata{k}.end(indexespd{k});
        peakind(k)=1;        
        matched(k)=0;  
        numpeaksc(k)=size(psc{k},1);            
        if numpeaksc(k)==0
            finished(k)=1;            
        else
            finished(k)=0;
        end
    end    
    
    psc1=-1;
    pec1=-1;
    psc2=-1;
    pec2=-1;
    
    while finished(1)==0 | finished(2)==0           
        
        if(finished(1)==0)
            psc1=psc{1}(peakind(1));       
            pec1=pec{1}(peakind(1));       
        end
            
        if(finished(2)==0)
            psc2=psc{2}(peakind(2));            
            pec2=pec{2}(peakind(2));
        end
        
        
        if psc1<=psc2                
            % peak 1 starts first
            if psc2<=pec1  
                % peak 2 starts before 1 ends, so they overlap
                matched(1)=1;
                matched(2)=1;
            end
        else
            % peak 2 starts first
            if psc1<=pec2  
                % peak 1 starts before 2 ends, so they overlap
                matched(1)=1;
                matched(2)=1;
            end
        end
        
        % peak 2 ends first or finished with 1
        if (pec1-pec2>=0 | finished(1)==1) & finished(2)==0           
                                                            
            % if peak not matched, it's new
            if matched(2)==0
                newpeaks(2)=newpeaks(2)+1;
            end            
            matched(2)=0;        
            
            % check whether it is last peak
            if peakind(2)<numpeaksc(2)
                % take next element in peak 2
                peakind(2)=peakind(2)+1;
            else
                finished(2)=1;
            end                
        end
        
        % peak 1 ends first or finished with 2
        if (pec1-pec2<=0 | finished(2)==1)  & finished(1)==0
            % if peak not matched, it's new
            if matched(1)==0 & finished(1)==0
                newpeaks(1)=newpeaks(1)+1;
            end
            matched(1)=0;        
            
            % check whether it is last peak
            if peakind(1)<numpeaksc(1)
                % take next element in peak 1
                peakind(1)=peakind(1)+1;
            else
                finished(1)=1;
            end                                    
        end        
        
    end  
end

display(['Dataset 1. Number of non-overlapping peaks: ' num2str(newpeaks(1))]);
display(['Dataset 2. Number of non-overlapping peaks: ' num2str(newpeaks(2))]);
