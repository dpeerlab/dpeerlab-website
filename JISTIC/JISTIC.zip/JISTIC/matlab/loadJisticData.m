function [ markerdata peaksdata regionsdata genedata] = loadJisticData( folder , genesAvailable)
% [ md pd rd] = loadJisticData(f,m,p,r) 
%               loads marker, peak and region information from JISTIC 
%               marker (m), peaks (p) and region (r) files in folder f. 
%               If only the folder is indicated, the function uses default 
%               names for the files.
%               The outputs are cells with the following format:
%               md{1}:marker md{2}:chromosome md{3}:location md{4}:ampqval   
%               md{5}:ampGscore md{6}:delqval md{7}:delGscore
%               pd{1}:type of peak pd{2}:chromosome pd{3}:- pd{4}:band 
%               pd{5}:qval pd{6}:broad? pd{7}:focal? pd{8}:start location
%               pd{9}:end location
%               rd{1}:type of region rd{2}:chromosome rd{3}:- rd{4}:band 
%               rd{5}:qval pd{6}:start location pd{7}:end location

    markerfile='markers.txt';
    peaksfile='peaks.txt';
    regionsfile='regions.txt';
    markerfile=[folder '/' markerfile];
    peaksfile=[folder '/' peaksfile];
    regionsfile=[folder '/' regionsfile];
    
    display('loading peaks...');
    peaksdata = loadJisticPeaks( peaksfile );
    display('loading regions...');
    regionsdata = loadJisticRegions( regionsfile );
    display('loading markers...');
    markerdata = loadJisticMarkers( markerfile );    
        
    % get gene data if requested
    genefiles={'AMP.genes.All.matrix';'DEL.genes.All.matrix'};
    if(genesAvailable==1)
        display('loading genes...');
        for k=[1:2]
            genedata{k}=getAlteredGenes(folder,genefiles{k},0);                
        end
    else
        genedata=0;
    end
end

function [genelist]=getAlteredGenes(folder,regionsfile,type)
    regionsfile=[folder '/' regionsfile];
    fidp=fopen(regionsfile);
    firstline=fgetl(fidp);
    fclose(fidp);
    regions= strread(firstline, '%s\t');
    data = dlmread(regionsfile, '\t', 1, 0);
    genes=data(:,1);
    data=data(:,2:end);
    
    
    if type==0
        intregidx=strmatch('PEAK',regions);        
    else 
        if type==1
            intregidx=setdiff(1:length(regions), strmatch('BROAD',regions));
        else
            intregidx=[1:size(regions,1)];
        end
    end
    
    intgenesidx=find(sum(data(:,intregidx),2)>0);
    genelist=genes(intgenesidx);
end
