function plotJistic( markerdata , peaksdata , regionsdata , desiredchromosome , ampordel, abthres, fignum, datapointcircle, horizontal, desiredregion)
%  plotJistic( md , pd , rd , dc , aod, abt, fgn, dpc, hz, dr) 
%             plots JISTIC qvalue and peaks for aberrations of type 
%             md,pd and rd is an cell array of the outputs obtained from loadJisticData
%             dc: chromosome to plot
%             aod: type of aberration (0=AMP,1=DEL) 
%             abt: threshold for the Q value
%             fgn: the number of the first figure to plot
%             dpc: whether to plot a circle for each datapoint
%             hz: whether to print figures horizontally
%             dr: region to plot.if not set, it takes the whole chromosome


colors={'r','b','c'};
colorlimit='g';
numsets=length(markerdata);
noregion=0;
if(nargin==9) 
    for i=1:numsets
       indexesmda{i}=find(markerdata{i}.chrom==desiredchromosome);            
    end
    desiredregion=[0 max(markerdata{1}.loc(indexesmda{1}))];
    noregion=1;
end

if ampordel==0
    destype='AMP';
else
    destype='DEL';
end

figure(fignum);
if horizontal==0
    subplot(3,1,1);
end

for i=1:numsets
    if ampordel==0
        gscoreabb{i}=markerdata{i}.ampgscore;
        qvalabb{i}=markerdata{i}.ampqval;
    else
        gscoreabb{i}=markerdata{i}.delgscore;
        qvalabb{i}=markerdata{i}.delqval;
    end
end


for k=[1:numsets]       
    indexesmd{k}=find(markerdata{k}.chrom==desiredchromosome & markerdata{k}.loc>=desiredregion(1) & markerdata{k}.loc<=desiredregion(2));
    indexespd{k}=find(peaksdata{k}.chrom==desiredchromosome & strcmp(peaksdata{k}.type, destype) & ( ...
    (peaksdata{k}.start>=desiredregion(1) & peaksdata{k}.start<=desiredregion(2)) | ...
    (peaksdata{k}.end>=desiredregion(1) & peaksdata{k}.end<=desiredregion(2)) ) );
    if(horizontal==0)
        ka=k;
    else
        ka=1;
        subplot(3,numsets,k);
        maxval=max(gscoreabb{1}(indexesmd{1}));
    end
    
    
    if datapointcircle==1
        plot(markerdata{k}.loc(indexesmd{k}),gscoreabb{k}(indexesmd{k})*((-1)^(ka+1)),colors{ka},'Marker','o');
    else
        plot(markerdata{k}.loc(indexesmd{k}),gscoreabb{k}(indexesmd{k})*((-1)^(ka+1)),colors{ka});
    end
    
    if(horizontal==0)
        hold on;
    else
        set(gca,'XLim',[desiredregion(1) desiredregion(2)]);
        set(gca,'YLim',[0 maxval]);
        if(noregion==0)
            title([destype ' G-score. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);
        else
            title([destype ' G-score. Chromosome ' num2str(desiredchromosome)]);
        end
        xlabel('location');
        ylabel('G-score');
    end
end

if(horizontal==0)
    hold off;
    set(gca,'XLim',[desiredregion(1) desiredregion(2)]);
    if(noregion==0)
        title([destype ' G-score. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);
    else
        title([destype ' G-score. Chromosome ' num2str(desiredchromosome)]);
    end
    xlabel('location');
    ylabel('G-score');
end
    


if horizontal==0
    subplot(3,1,2);
end
    
for k=[1:numsets] 
    if(horizontal==0)
        ka=k;
    else
        ka=1;
        subplot(3,numsets,k+numsets);
        maxval=max(max(-log10(qvalabb{1}(indexesmd{1}))),-log10(abthres));
    end
    if datapointcircle==1
        plot(markerdata{k}.loc(indexesmd{k}),-log10(qvalabb{k}(indexesmd{k}))*((-1)^(ka+1)),colors{ka},'Marker','o');
    else
        plot(markerdata{k}.loc(indexesmd{k}),-log10(qvalabb{k}(indexesmd{k}))*((-1)^(ka+1)),colors{ka});
    end
    
    hold on;
    plot([desiredregion(1) desiredregion(2)],[-log10(abthres)*((-1)^(ka+1)) -log10(abthres)*((-1)^(ka+1))],colorlimit);
    hold off;
    
    
    if(horizontal==0)
        hold on;        
    else        
        set(gca,'XLim',[desiredregion(1) desiredregion(2)]);
        set(gca,'YLim',[0 maxval]);
        if(noregion==0)
            title([destype ' q-value. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);
        else
            title([destype ' q-value. Chromosome ' num2str(desiredchromosome)]);
        end
        xlabel('location');
        ylabel('-log(q-val)');
    end
end

if(horizontal==0)
    hold off
    set(gca,'XLim',[desiredregion(1) desiredregion(2)]);
    if(noregion==0)
        title([destype ' q-value. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);
    else
        title([destype ' q-value. Chromosome ' num2str(desiredchromosome)]);
    end
    xlabel('location');
    ylabel('-log(q-val)');
end

if horizontal==0
    subplot(3,1,3);
end
for k=[1:numsets]    
    if(horizontal==0)
        ka=k;
    else
        ka=1;
        subplot(3,numsets,k+numsets*2);
        maxval=max(-log10(peaksdata{1,5}(indexespd{1})));
    end
    %numpeaks=size(peaksdata{k,8}(indexespd{k}),1);
    numpeaks=size(indexespd{k},1);
    peaksdatax=[peaksdata{k}.start(indexespd{k}) ; peaksdata{k}.end(indexespd{k})+1 ; desiredregion(1) ; desiredregion(2) ];    
    peaksdatay= [-log10(peaksdata{k}.qval(indexespd{k})) ; zeros(numpeaks+2,1) ];
    
    
    indstbef=find(peaksdatax(1:numpeaks*2,1)<=desiredregion(1));
    
    if size(indstbef,1)~=0
        peaksdatay(numpeaks*2+1)=peaksdatay(indstbef);
    end
    
    indendaft=find(peaksdatax(1:numpeaks*2,1)>=desiredregion(2));
    if size(indendaft,1)~=0
        peaksdatay(numpeaks*2+2)=peaksdatay(indendaft-numpeaks);
    end
    
    [peaksdatax indsortpd]=sort(peaksdatax);
    peaksdatay=peaksdatay(indsortpd);       
    stairs(peaksdatax,peaksdatay*((-1)^(ka+1)),colors{ka});
    if(horizontal==0)
        hold on;
    else        
        set(gca,'XLim',[desiredregion(1) desiredregion(2)]);
        set(gca,'YLim',[0 maxval]);
        if(noregion==0)
            title([destype ' peaks. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);            title([destype ' q-value. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);
        else
            title([destype ' peaks. Chromosome ' num2str(desiredchromosome)]);
        end
        xlabel('location');
        ylabel('-log(q-val)');
    end
end

if(horizontal==0)
    hold off
    set(gca,'XLim',[desiredregion(1) desiredregion(2)]);
    if(noregion==0)
        title([destype ' peaks. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);            title([destype ' q-value. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);
    else
        title([destype ' peaks. Chromosome ' num2str(desiredchromosome)]);
    end
    xlabel('location');
    ylabel('-log(q-val)');
end