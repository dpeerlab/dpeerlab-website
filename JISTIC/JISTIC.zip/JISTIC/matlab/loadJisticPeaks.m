function [ result ] = loadJisticPeaks( peaksfile )
    %loadJisticPeaks return parse peaks in file
    % result{:}.type
    % result{:}.chrom
    % result{:}.start
    % result{:}.end
    % result{:}.qval
    % result{:}.broad
    % result{:}.focal
    
    %  peaksdata{1}: type of peak: 'AMP' or 'DEL'
    %  peaksdata{2}: chromosome
    %  peaksdata{8}: start location
    %  peaksdata{9}: end location    
    
    
    fidp=fopen(peaksfile);
    fgetl(fidp);
    %peak	qvalue	broad	focal
    %PEAK:AMP:chr1:554317(1p36:33)	0.10170764579637906	N	Y
    %PEAK:AMP:chr1:554317-554467(1p36:33)	0.10170764579637906	N	Y
    peaksdata= textscan(fidp,'PEAK:%3s:chr%d:%[^()](%[^()]) %f %c %c' ,'delimiter','\t');  
    fclose(fidp);
    
     
    result.type=peaksdata{1};
    result.chrom=peaksdata{2};
    result.qval=peaksdata{5};
    result.start=zeros(length(peaksdata{1}),1);
    result.end=zeros(length(peaksdata{1}),1);
    result.broad=zeros(length(peaksdata{1}),1);
    result.focal=zeros(length(peaksdata{1}),1);
        
    for k = 1:length(peaksdata{1})
        result.broad(k)=peaksdata{6}(k)=='Y';
        result.focal(k)=peaksdata{7}(k)=='Y';
                
        % get start location 
        a=str2num(regexprep(peaksdata{3}{k}, '-', ';'));
        result.start(k)=a(1);
        % if end location exists, get end, otherwise set start
        if size(a,1)==2
            result.end(k)=a(2);
        else
            result.end(k)=a(1);
        end 
        %{
        result(k).type=peaksdata{1}{k};
        result(k).chrom=peaksdata{2}(k);
        result(k).qval=peaksdata{5}(k);
        result(k).broad=peaksdata{6}(k)=='Y';
        result(k).focal=peaksdata{7}(k)=='Y';
        
        
        % get start location 
        a=str2num(regexprep(peaksdata{3}{k}, '-', ';'));
        result(k).start=a(1);
        % if end location exists, get end, otherwise set start
        if size(a,1)==2
            result(k).end=a(2);
        else
            result(k).end=a(1);
        end 
        %}
    end    
end