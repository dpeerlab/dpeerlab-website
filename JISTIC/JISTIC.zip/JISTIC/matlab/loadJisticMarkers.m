function [ result ] = loadJisticMarkers( markerfile )
    %loadJisticMarkers return parse peaks in file
    % result{:}.chrom
    % result{:}.loc    
    % result{:}.ampqval
    % result{:}.ampgscore
    % result{:}.delqval
    % result{:}.delgscore

    fidm=fopen(markerfile);
    % ignore first line
    fgetl(fidm);
    % read data from file
    % markername chromosome location ampqval delqval
    markerdata = textscan(fidm,'%s chr%d:%d %f %d %f %d %*s %*s','delimiter','\t');  
    fclose(fidm);
    %fields = {'name', 'chrom', 'loc','ampqval' ,'ampgscore' ,'delqval' , 'delgscore'};
    result.chrom=markerdata{2};
    result.loc=markerdata{3}; 
    result.ampqval=markerdata{4}; 
    result.ampgscore=markerdata{5}; 
    result.delqval=markerdata{6}; 
    result.delgscore=markerdata{7}; 
    %{
    for k = 1:length(markerdata{1})
        display(num2str(k));
        result(k).chrom=markerdata{2}(k);
        result(k).loc=markerdata{3}(k); 
        result(k).ampqval=markerdata{4}(k); 
        result(k).ampgscore=markerdata{5}(k); 
        result(k).delqval=markerdata{6}(k); 
        result(k).delgscore=markerdata{7}(k); 
    end   
    toc
    %}