function statsJistic( markerdata , peaksdata , regionsdata , desiredchromosome , ampordel, fignum,desiredregion)
%  statsJistic( md , pd , rd , dc , aod, cut, fgn, dr) 
%             obtains JISTIC relevant statistics for aberrations of type 
%             ampordel (0=AMP,1=DEL) in region dr for chromosome dc (dc=-1 
%             for all chromosomes)
%             md,pd and rd are as obtained from loadJisticData
%             dc: chromosome to plot (-1 if all)
%             aod: type of aberration (0=AMP,1=DEL)
%             fgn: the number of the first figure to plot
%             dr: region to plot.if not set, it takes the whole chromosome


if(nargin==7) 
    if desiredchromosome==-1        
        desiredregion=[0 max(markerdata.loc)];
    else
        indexesmda=find(markerdata.chrom==desiredchromosome);
        desiredregion=[0 max(markerdata.loc(indexesmda))];
    end
end

if ampordel==0
    destype='AMP';
else
    destype='DEL';
end

% markers
if desiredchromosome==-1
    indexesmd=find(markerdata.loc>=desiredregion(1) & markerdata.loc<=desiredregion(2));
else
    indexesmd=find(markerdata.loc==desiredchromosome & markerdata.loc>=desiredregion(1) & markerdata.loc<=desiredregion(2));
end
nummarkers=size(indexesmd,1);
display('* Data statistics *');
display(['Number of markers: ' num2str(nummarkers)]);

% peaks
if desiredchromosome==-1
    indexespd=find(strcmp(peaksdata.type, destype) & ( ...
    (peaksdata.start>=desiredregion(1) & peaksdata.start<=desiredregion(2)) | ...
    (peaksdata.end>=desiredregion(1) & peaksdata.end<=desiredregion(2)) ) );
else
    indexespd=find(peaksdata.chrom==desiredchromosome & strcmp(peaksdata.type, destype) & ( ...
    (peaksdata.start>=desiredregion(1) & peaksdata.start<=desiredregion(2)) | ...
    (peaksdata.end>=desiredregion(1) & peaksdata.end<=desiredregion(2)) ) );
end

numpeaks=size(indexespd,1);
display(['Number of peaks: ' num2str(numpeaks)]);
if numpeaks>0    
    numbroadpeaks=size(find(peaksdata.broad(indexespd)),1);
    display(['Number of broad peaks: ' num2str(numbroadpeaks)]);
    numfocalpeaks=size(find(peaksdata.focal(indexespd)),1);
    display(['Number of focal peaks: ' num2str(numfocalpeaks)]);

    peaksavgqval=mean(peaksdata.qval(indexespd));
    peaksminqval=min(peaksdata.qval(indexespd));
    peaksmaxqval=max(peaksdata.qval(indexespd));
    peaksstdqval=std(peaksdata.qval(indexespd));


    display(['Peak average q-val: ' num2str(peaksavgqval)]);
    display(['Peak min q-val: ' num2str(peaksminqval)]);
    display(['Peak max q-val: ' num2str(peaksmaxqval)]);
    display(['Peak q-val std: ' num2str(peaksstdqval)]);

    % calculate distance between peaks

    peaksdist=zeros(1,numpeaks);
    peaksloco=peaksdata.start(indexespd);
    peakslocd=peaksdata.end(indexespd);
    peakschrom=peaksdata.chrom(indexespd);
    % replace NaN end loc with start loc
    nansind=find(isnan(peaksdata.end(indexespd)));
    peakslocd(nansind)=peaksloco(nansind);

    j=1;
    for k=[1:numpeaks-1]    
        if peakschrom(k)==peakschrom(k+1)
            peaksdist(1,j)=peaksloco(k+1)-peakslocd(k);
            j=j+1;
        end
    end
    
    if numpeaks>1
        % remove elements that do not count
        peaksdist=peaksdist(1,1:j-1);

        avgpeaksdist=mean(peaksdist);
        minpeaksdist=min(peaksdist);
        stdpeaksdist=std(peaksdist);

        display(['Peak distance min: ' num2str(minpeaksdist)]);
        display(['Peak distance average: ' num2str(avgpeaksdist)]);
        display(['Peak distance std: ' num2str(stdpeaksdist)]);
        

        if fignum >-1
            figure(fignum+1);
            hist(log10(peaksdist),100);
            if(desiredchromosome==-1)
                title([destype ' log peak distance histogram. All chromosomes']);
            else
                title([destype ' log peak distance histogram. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);
            end
            xlabel('log(distance)');
            ylabel('n. of peaks');
        end
    end

    peakssize=peakslocd-peaksloco+1;

    avgpeakssize=mean(peakssize);
    varpeakssize=std(peakssize);

    
    display(['Peak size average: ' num2str(avgpeakssize)]);
    display(['Peak size std: ' num2str(varpeakssize)]);
    
    if fignum >-1
        figure(fignum+2);
        hist(peakssize,100);        
        if desiredchromosome==-1            
                title([destype ' peak size histogram. All chromosomes']);
        else                
                title([destype ' peak size histogram. Chrom ' num2str(desiredchromosome) '. Region: ' num2str(desiredregion)]);
        end
        xlabel('size');
        ylabel('n. of peaks');
    end
end