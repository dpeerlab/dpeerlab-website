
%clear all;
genesAvailable=1;
folder1='./../../data/standardNoDuplicatesGNoXYBroadFilteredCNVNew3';
folder2='./../../data/standardNoDuplicatesGNoXYBroadFilteredCNV';


[ markerdata1 peaksdata1 regionsdata1 peakgenes1] = loadJisticData(folder1,genesAvailable);
[ markerdata2 peaksdata2 regionsdata2 peakgenes2] = loadJisticData(folder2,genesAvailable);
%}


%[ markerdata peaksdata regionsdata peakgenes] = loadJisticData(folder,genesAvailable);
%}
desiredregion= [0 143481244]; 
desiredchromosome=15;
ampordel=1;
cut=0.25;

%plotJistic plots 1 or 2 sets of JISTIC outputs
%plotJistic( [markerdata] , [peaksdata] , [regionsdata] , desiredchromosome , ampordel, cut, 10,0,0,desiredregion);

%plotJistic( [markerdata1] , [peaksdata1] , [regionsdata1] , desiredchromosome , ampordel, cut, 12,0,0,desiredregion);
%plotJistic( [markerdata1] , [peaksdata1] , [regionsdata1] , desiredchromosome , ampordel, cut, 12,0,0);

%plotJistic( [markerdata2] , [peaksdata2] , [regionsdata2] , desiredchromosome , ampordel, cut, 11,0,0,desiredregion);
%plotJistic( [markerdata2] , [peaksdata2] , [regionsdata2] , desiredchromosome , ampordel, cut, 11,0,0);


clear markerdatat;
markerdatat{1}=markerdata1;
markerdatat{2}=markerdata2;
clear peaksdatat;
peaksdatat{1}=peaksdata1;
peaksdatat{2}=peaksdata2;
clear regionsdatat;
regionsdatat{1}=regionsdata1;
regionsdatat{2}=regionsdata2;


plotJistic( markerdatat , peaksdatat, regionsdatat, desiredchromosome , ampordel, cut, 10,0,0);



% compareJistics compares two outputs, includes plotJistic
compareJisticOutputs(markerdatat , peaksdatat, regionsdatat , desiredchromosome , ampordel, cut,15);
%compareJisticOutputs(markerdatat , peaksdatat, regionsdatat , desiredchromosome , ampordel, cut,15,desiredregion);

%{
if(genesAvailable==1)    
    abbtext={'AMP','DEL'};
    for k=[1,2]
        display([abbtext{k} ' peak genes']); 
        display([num2str(size(peakgenes1{k},1)) ' genes in 1']); 
        display([num2str(size(peakgenes2{k},1)) ' genes in 2']); 
        p1{k} = setdiff(peakgenes1{k}, peakgenes2{k}); 
        display('Genes in 1 but not 2:'); 
        disp(p1{k});
        p2{k} = setdiff(peakgenes2{k}, peakgenes1{k}); 
        display('Genes in 2 but not 1:'); 
        disp(p2{k});
        
        
    end
end
%}

% statJistic gives you more statistics than compareJistics
statsJistic( markerdata1 , peaksdata1, regionsdata1 , desiredchromosome , ampordel, 11,desiredregion);
%statsJistic( markerdata1 , peaksdata1 , regionsdata1 , desiredchromosome , ampordel, 15);

