function zoomtb = zoominb_prepare(dataset, window, varargin)
    %%% prepare data for zoom-in (bayes version)

    if nargin < 2,     
        window = 30000; %30k
    end

    para.algo = {'lasso', 'elastic', 'QTL'};
    para.doset = {'G', 'RG', 'EG'};
    para.btthres = 0.5;
    para.genelocdb = '../DATA/SGD/SGD';
    para.detailmarker = 'marker3K';
    para.SNPfilter = [];
    
    para = assignpara(para, varargin{:});
    
    markers = collect_marker(dataset, 'algo', para.algo, 'doset', para.doset, 'btthres', para.btthres);

    genelocdb = load(para.genelocdb);
    fd = fieldnames( genelocdb );
    genelocdb = genelocdb.(fd{1});
    
    markerdb = load(para.detailmarker);
    fd = fieldnames( markerdb );
    markerdb = markerdb.(fd{1});

    datastruct = loadData(dataset);

    orf = datastruct.geneid;

    if isfield(datastruct, 'mergedngene')
        orf(datastruct.mergedgene(:,1)) = datastruct.geneid(datastruct.mergedgene(:,2));
    end
    gi = strIndexQuery(genelocdb.orf, orf);
    gi = find(gi~=-1);
    probeindex = NaN(length(orf),1);
    probeindex(gi) = gene2ProbeMarker(orf(gi), genelocdb, [markerdb.chrm markerdb.pos]);
    clear markerdb

    %snp filter
    if isempty(para.SNPfilter)
        para.SNPfileter = true(length(datastruct.geneid), 1);
    end
        

    %collect all unique markers first
    ncond = length(datastruct.conds);
    munion = {};

    for condi = 1:ncond
        munion = union(munion, markers{condi}(:,1));    
    end

    %get ORFs for each locus
    %mtb = [gi] for each marker in datastruct.markers
    mtb = cell(length(datastruct.markers),1);
    gtb = geneInMarker(munion, window, 'genelocdb', genelocdb);
    mi = strIndexQuery(datastruct.markers, munion);
    for i = 1:length(mi)
        gi = strIndexQuery(datastruct.geneid, gtb{i});
        gi = gi(gi~=-1);
        if ~isempty(para.SNPfilter)
            mtb{mi(i)} = gi( para.SNPfilter(gi) );
        else
            mtb{mi(i)} = gi;
        end
    end

    %build table for zoomin
    zoomtb = cell(ncond,1);
    for condi = 1:ncond
        miset = strIndexQuery(datastruct.markers, markers{condi}(:,1));
        subtb = cell(0,3);
        for i = 1:length(miset) %for each merged marker linked to the condition
            currentgi = cell2mat(subtb(:,1));
            if ~isempty(currentgi)
                currentgi = currentgi(:,1);
            end
            newgi = mtb{miset(i)};
            [tmp curgii ngii] = intersect(currentgi, newgi);
            %these already in current tb: update indicator and mi-list
            for tmpi = 1:length(curgii)
                subtb{curgii(tmpi),2} = ...
                    subtb{curgii(tmpi),2} | markers{condi}{i,2};
                %subtb{curgii(tmpi),3} = ...
                %    union(subtb{curgii(tmpi),3}, markers{condi}{i,1});
                subtb{curgii(tmpi),3} = ...
                    union(subtb{curgii(tmpi),3}, miset(i));
            end
            %these are not in current tb: add them
            for tmpi = setdiff(1:length(newgi), ngii)
                subtb{end+1,1} = [newgi(tmpi), probeindex(newgi(tmpi))];
                subtb{end,2} = markers{condi}{i,2};
                %subtb{end,3} = {markers{condi}{i,1}};
                subtb{end,3} = [miset(i)];
            end
        end
        zoomtb{condi} = subtb;
    end

    zoomtb = collapse_region(zoomtb);   

end


function newzoomtb = collapse_region(zoomtb)
    %Add ranking for likehood and pval for genes in the same regionion (merged
    %markers, may be multiple)
    %guilty, struct from zoom_bayes
    %
    %return
    %   new zoomtb, additional column for each cell [merged mi]
    %
    
    ncond = length(zoomtb);
    newzoomtb = zoomtb;
    
    for condi = 1:ncond
        if ~isempty(zoomtb{condi})
            region = {};
            for i = 1:size(zoomtb{condi},1)
                found = false;
                for j = 1:size(region,1)
                    if ~isempty(intersect(region{j,1},zoomtb{condi}{i,3})) 
                        found = true;
                        region{j,1} = union(region{j,1},zoomtb{condi}{i,3});
                        region{j,2} = [region{j,2} i];
                        break;
                    end
                end
                if ~found
                    region{end+1,1} = zoomtb{condi}{i,3};
                    region{end,2} = i;
                end
            end
            for ri = 1:size(region,1)
                %fill in new zoomtb with merged mi infomation
                if size(zoomtb{condi},2) == 3
                    newzoomtb{condi}(region{ri,2},4) = {region{ri,1}};
                end
            end
        end
    end
end
