function zoomlike = combineperm(zoomlike, zoompval)

    ncond = length(zoomlike.wlike);

    if isempty(zoompval)
        fprintf('no pvalues to be appended\n');
        for i = 1:ncond
            zoomlike.wlike{i}(:, 10:11) = NaN;
        end
    else
        assert(length(zoomlike.wlike)==length(zoompval), ...
            'length inconsistent between permutation p-val and likelihood');

        %zoompval{.}(:,1) should be the sum of zoomlike{.}.wlike(:,3:4),
        %which the first and second term of zoom-in function=                
        for i = 1:ncond
            if isempty(zoomlike.wlike{i}) && isempty(zoompval{i})
                continue
            end
            if any(abs( sum(zoomlike.wlike{i}(:,3:4), 2) - zoompval{i}(:,1)) > 1e-5)
                fprintf('warning, pval(:,1) ~= sum(wlike(:,3:4),2); condi=%d\n', i);
            end
            zoomlike.wlike{i}(:, 10:11) = zoompval{i}(:, 2:3);
        end
    end