function [res resregion] = tableChain(dataset, LRPres, rQTL, LRP_tb, varargin)
    %Filter tritest results to only sifnificant possible triangles.
    %The return results will have significant G->R and G->P edges.
    %For R->P, it is assigned with different class of significance: [-1, 0,
    %1, 2] for {insignificant, local, regional, strong}.
    %
    %dataset: string name of the dataset
    %LRPres: triangle test results
    %rQTL: regulator QTL
    %LRP_tb: LRPtb from prepareLRPtb.m
    %texttable: true: return text table; false: return cell array contains
    %filtered results
    %
    %res: table or filtered results
    %
    %revised: 01/20/09, no comparison between E->D and L->D
    %
        
    
    if ischar(LRP_tb)
        LRP_tb = load(LRP_tb);
        fd = fieldnames(LRP_tb);
        LRP_tb = LRP_tb.(fd{1});
    end
    if ischar(rQTL)       
        rQTL = load(rQTL);
        fd = fieldnames(rQTL);
        rQTL = rQTL.(fd{1});
    end
    if ischar(LRPres)
        LRPres = load(LRPres);
        fd = fieldnames(LRPres);
        LRPres = LRPres.(fd{1});
    end

    %print indexes of genes instead of gene names (default=false);
    para.printgi = false;
    %threshold for significance of an edge
    para.edgepvalthres = 0.05;
    %low threshold to further merge markers
    para.loosemergemarkercorthres = 0.6;
    para.mergemarkerindexthres = 10;
    para.texttable = true;
    para.doset = {'R', 'RG'};
    para.allset = {'R','D','E','RG','DG','EG'}; %should be the same as fset in prepareLRPtb.m
    para.sourcecode = {'r','d','e','R','D','E'};
    para.fdrqc = 0.004;
    
    para = assignpara(para, varargin{:});
    
    sourcemask = ismember(para.allset, para.doset);    
    
    datastruct = loadData(dataset);
    data = dataPrepare(datastruct, 'A');
    indexsourcefield = 'gindexsource';

    [allq allp pc] = getpc(LRPres, rQTL, para.edgepvalthres, LRP_tb, indexsourcefield, sourcemask, para.fdrqc); %#ok<ASGLU>
    fprintf('FDR=%g, pc<%g\n', para.fdrqc, pc);
    
    if para.texttable
        res = {'condi','cond','R','R pval','R mse','L','L pval','L mse',...
            'RL pval1','RL pval2','class','source','cor'};
        resregion = [];
    else
        res = cell(length(datastruct.conds),1);
        resregion = cell(length(datastruct.conds),1);
    end
        
%     res = {'condi','cond','R','R pval','R mse','L','L pval','L mse',...
%         'RL pval1','RL pval2', 'source'};

    ncond = length(LRPres);
    for i = 1:ncond
        condi = LRPres{i}.condi;
        [RLtb region] = sigClass(datastruct, LRPres{i}, rQTL, ...
            LRP_tb.(indexsourcefield){LRP_tb.cond==condi}, para, sourcemask, pc);
        %tb:[gi perm_mi RPp RPmse GPp GPmse GRp1 GRp2 sig]
        %sig: -1=insignificant, 0=significant triangle, 1=significant triagle
        %with neighbor correction, 2=strong intermediator
        nrows = size(RLtb, 1);
        if length(region) ~= nrows
            error('length inconst between region and RLtb, %d, %d, %d, %d.\n', ...
                i, condi, length(region), nrows);
        end
        if ~para.texttable
            res{condi} = RLtb;
            resregion{condi} = region; %#ok<AGROW>
        else
            tmpgitb = cell2mat(LRP_tb.(indexsourcefield){LRP_tb.cond==condi}(:,1));
            for rowi = 1:nrows
                mstr = markerStr(datastruct.markers, region{rowi}, RLtb(rowi,2));
                if para.printgi
                    genename = RLtb(rowi,1);
                    lrppval = RLtb(rowi,3);
                else
                    genename = data.xname{RLtb(rowi,1)};
                    lrppval = sprintf('%g',RLtb(rowi,3));
                end
                row = {condi, datastruct.conds{condi}, ...
                    genename, ...
                    lrppval, sprintf('%f',RLtb(rowi,4)), ...
                    mstr, ...
                    sprintf('%g',RLtb(rowi,5)), sprintf('%f',RLtb(rowi,6)), ...
                    sprintf('%g',RLtb(rowi,7)), sprintf('%g',RLtb(rowi,8)), ...
                    sigClassStr(RLtb(rowi,9)), ...
                    sourceStr(LRP_tb.(indexsourcefield){LRP_tb.cond==condi}{find(tmpgitb==RLtb(rowi,1)),2}, para.sourcecode), ...
                    sprintf('%f',corr(data.x(RLtb(rowi,1),:)',data.y(condi,:)','rows','pairwise'))}; %#ok<FNDSB>
                res = [res; row]; %#ok<AGROW>
            end
        end        
    end
    
end


function sstr = sourceStr(indicator, code)    
    sstr = '';
    for i = 1:length(indicator)
        if indicator(i)
            sstr = [sstr code{i}]; %#ok<AGROW>
        else
            sstr = [sstr '-']; %#ok<AGROW>
        end
    end
end

function cstr = sigClassStr(sig)
    if sig == -1
        cstr = 'No';
    elseif sig == 0
        cstr = 'Local';
    elseif sig == 1
        cstr = 'Regional';
    elseif sig == 2
        cstr = 'Strong';
    else
        cstr = 'Error';
    end
end

function [RLtb region] = sigClass(datastruct, LRPsub, rQTL, sourcesub, para, sourcemask, pc)
    %process for each condition
    
    [sourcetb] = filterSource(sourcesub, sourcemask);
    
    %tb:[gi perm_mi RPp RPmse GPp GPmse GRp1 GRp2 sig]
    [RLtb region] = extRLtb(LRPsub, rQTL, para.edgepvalthres, sourcetb);    
    if isempty(RLtb)
        return
    end
    RLtb(:,9) = -1; %set all as insignificant first
    %sig: -1=insignificant, 0=significant triangle, 1=significant triagle
    %with neighbor correction, 2=strong intermediator
    [merged_regi umi] = groupMarker(datastruct, region, para.loosemergemarkercorthres, para.mergemarkerindexthres);
    ugi = unique(RLtb(:,1));
    for i = 1:length(ugi) %each gene
        mask = find(RLtb(:,1) == ugi(i));     %row indexes in RLtb    
        regivector = zeros(length(mask),1); %region index for G in each triangle
        for j = 1:length(mask) %each triangle
            tbrowi = mask(j);
            regivector(j) = merged_regi( umi==RLtb(tbrowi,2) );            
            %if RLtb(tbrowi,3) < RLtb(tbrowi,5) %!!!!!
            if RLtb(tbrowi,3) < pc
                RLtb(tbrowi,9) = RLtb(tbrowi,9) + 1; %sig = 0
            end
        end
        %now, for this gene, each triangle is tested, but not corrected for
        %neighboring genotypes; do correction
        uregi = unique(regivector);
        for j = 1:length(uregi) %each region of genotypes (a bunch of triangles)
            tbrowi = mask(regivector == uregi(j)); %row indexes in RLtb for the same region
            if sum(RLtb(tbrowi,9)==0) == length(tbrowi) %all triangles in the region is significant
                RLtb(tbrowi,9) = RLtb(tbrowi,9) + 1; %sig = 1
            end
        end
        %now, for this gene, significance is corrected for neighboring
        %genotypes; see if it's a strong intermediator
        if sum(RLtb(mask,9)==1) == length(mask)
            RLtb(mask,9) = RLtb(mask,9) + 1; %sig = 2
        end
    end
end

function [sourcetb sourceindicator] = filterSource(sourcesub, sourcemask)
    %sourcetb = [gi {1, 0}]
    gi = cell2mat(sourcesub(:,1));
    sourcetb = zeros(length(gi),2);
    sourceindicator = sourcesub(:,2);
    sourcetb(:,1) = gi;    
    for i = 1:length(gi)
        sourcetb(i,2) = (sum( sourcesub{i,2} & sourcemask ) > 0);
    end
end

function [regi unionmi] = groupMarker(datastruct, mcell, mcorthres, mindexthres)
    nm = size(mcell,1);    
    unionmi = [];    
    for i = 1:nm
        unionmi = union(unionmi, mcell{i});
    end
    if length(unionmi) > 1
        regi = mergeMarker(datastruct.genotype(unionmi,:)',mcorthres, unionmi, mindexthres);
    elseif length(unionmi) == 1
        regi = 1;
    else
        regi = [];
    end
    %check how far the markers are away
    ureg = unique(regi);
    for i = 1:length(ureg)
        tmp = unionmi(regi==ureg(i));
        if max(tmp)-min(tmp) > mindexthres
            warning('some merged G are %d marker indexes away(%d~%d)\n',max(tmp)-min(tmp),min(tmp),max(tmp)); %#ok<WNTAG>
        end
    end
end

function [tb region] = extRLtb(LRPsub, rQTL, sigthres, sourcetb)
    %for each condition
    %build matrix tb:[gi perm_mi RPp RPmse GPp GPmse GRp1 GRp2 sig]
    %region: cell, #row(tb) x 1, indicating the region tested
    %
    tb = NaN(0,9); %last one used for significance class later
    region = cell(0,1);
    nreg = length(LRPsub.locus);    
    skipGR = 0;
    skipGP = 0;
    for regi = 1:nreg
        %check G->P significance
        if LRPsub.Ltest(regi,1) > sigthres
            skipGP = skipGP + 1;
            continue
        end
        for i = 1:length(LRPsub.regulator{regi})
            gi = LRPsub.regulator{regi}(i);
            %filtered by source
            valid = sourcetb(sourcetb(:,1)==gi, 2);
            if valid == 0
                continue;
            end
            if isempty(valid)
                continue;
            end
            %check G->R significance
            ri = find(rQTL.yi==gi);
            mi = find(rQTL.xi{ri}==LRPsub.locus(regi));
            if isfield(rQTL, 'p2')
                if rQTL.p1{ri}(mi) > sigthres || rQTL.p2{ri}(mi) > sigthres
                    skipGR = skipGR + 1;
                    continue
                end
            else
                if rQTL.p1{ri}(mi) > sigthres
                    skipGR = skipGR + 1;
                    continue
                end
            end

            tmpp2 = NaN;
            if isfield(rQTL, 'p2'), tmpp2 = rQTL.p2{ri}(mi); end
            
            tb(end+1,1:8) = [gi, LRPsub.locus(regi), ...
                LRPsub.Rtest{regi}(i,1), LRPsub.Rtest{regi}(i,2), ...
                LRPsub.Ltest(regi,1), LRPsub.Ltest(regi,2), ...
                rQTL.p1{ri}(mi), tmpp2]; %#ok<AGROW>
            region{end+1,1} = LRPsub.region{regi}; %#ok<AGROW>
        end
    end
    %sorted by gene index
    [tb si] = sortrows(tb);
    region = region(si);
end

function [q p pc] = getpc(LRPres, rQTL, sigthres, LRP_tb, indexsourcefield, sourcemask, qc)
    p = [];
    for i = 1:length(LRPres)
        LRPsub = LRPres{i};
        condi = LRPres{i}.condi;
        sourcesub = LRP_tb.(indexsourcefield){LRP_tb.cond==condi};
        [sourcetb] = filterSource(sourcesub, sourcemask);
        nreg = length(LRPsub.locus);    
        skipGR = 0;
        skipGP = 0;
        for regi = 1:nreg
            %check G->P significance
            if LRPsub.Ltest(regi,1) > sigthres
                skipGP = skipGP + 1;
                continue
            end
            for ii = 1:length(LRPsub.regulator{regi})
                gi = LRPsub.regulator{regi}(ii);
                %filtered by source
                valid = sourcetb( sourcetb(:,1)==gi, 2);
                if isempty(valid)
                    continue;
                elseif valid == 0
                    continue;
                end
                %check G->R significance
                ri = find(rQTL.yi==gi);
                mi = find(rQTL.xi{ri}==LRPsub.locus(regi));
                if isfield(rQTL, 'p2') %has p2 field (permutation)
                    if rQTL.p1{ri}(mi) > sigthres || rQTL.p2{ri}(mi) > sigthres
                        skipGR = skipGR + 1;
                        continue
                    end
                else
                    if rQTL.p1{ri}(mi) > sigthres
                        skipGR = skipGR + 1;
                        continue
                    end
                end
                p = [p; LRPsub.Rtest{regi}(ii,1)]; %#ok<AGROW>
            end
        end
    end
    if ~isempty(p)
        [q pc] = FDR(p, qc);
    else
        q = [];
        pc = 1;
    end
end


function s = markerStr(markers, indexes, mainindex)
    if nargin < 3, mainindex = indexes(1); end
    rest = setdiff(indexes, mainindex);
    n = length(rest);
    s = markers{mainindex};
    if n > 0
        s = [s ' ('];
        for i = 1:n
            s = [s ' ' markers{rest(i)}]; %#ok<AGROW>
        end
        s = [s ')'];
    end
end