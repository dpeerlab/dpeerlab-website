function [like like_dle like_el] = regLikelihood(E, L, D, region, weight)
    %D is the growth: sample x 1    
    %L is the locus: sample x genes (each gene paired with a locus)
    %E is the expression data: sample x genes
    %region is the merged region: sample x 1
    %weight is: 2 x 1; if not specified, assume equal weights
    %
    
    vi = ~isnan(D);
    nsample = sum(vi);
    ngene = size(E,2);
    if ngene~=size(L,2)
        error('inconst size in L and E\n');
    end
    
    if nargin < 5
        weight = [1; 1];
    end
    if length(weight) ~= 2
        error('weight length error %d\n',length(weight));
    end
    
    y = zeromean_univar_normalization(D(vi),1);
    x1 = zeromean_univar_normalization(L(vi,:),1); 
    x2 = zeromean_univar_normalization(E(vi,:),1); 
    basex = zeromean_univar_normalization(region(vi),1);
    const = ones(nsample,1);
    
    % solve y = xb
    % b = x\y; r = y-yhat = y - x(x\y);
    % include const term evem though data are standardized
    
    %D ~ L; take the variance; dof = 2; using region    
    var_dl = sum((y - [const basex] * ([const basex] \ y)).^2) / (nsample-2);
    
    %D ~ L + E
    sse_dle = NaN(ngene,1);    
    for i = 1:ngene
        sse_dle(i) = sum((y - [const x1(:,i) x2(:,i)] * ([const x1(:,i) x2(:,i)] \ y)) .^ 2);        
    end
    
    %E ~ L; singleton; not suitable for data that's challenging for machine
    %precision; dof = 2 (even though we standardized the data)    
    sse_el = (sum(x2.^2) - (sum(x2.*x1).^2) ./ sum(x1.^2))'; %column    
    var_el = sse_el / (nsample-2);    
    
    c = -nsample*log(sqrt(2*pi));
    
    like_dle = c - nsample.*log(sqrt(var_dl)) - 0.5./var_dl.*sse_dle;    
    like_el = c - nsample.*log(sqrt(var_el)) - 0.5*(nsample-2);
    %like = like_dle + like_el;
    like = [like_dle like_el] * weight;
    
    
    
