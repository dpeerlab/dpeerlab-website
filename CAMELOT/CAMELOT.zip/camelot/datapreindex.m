function datai = datapreindex(datastruct)
% generate indices for cv, bt

global camelotpara

%default setting
para.paraportion = 0.67; %.67 of the data used for parameterization
para.paracv = 10; %10-fold for para.paraportion data to choose parameters
para.cv = 10; %10-fold for all data to assess models
para.bt = 200; %200 bootstraps
para.seed = 135;

if ~isempty(camelotpara)
    %copy from global setting
    fd = fieldnames(para);
    for i = 1:length(fd)
        if isfield(camelotpara, fd{i})
            para.(fd{i}) = camelotpara.(fd{i});
        end
    end
    clear camelotpara
else     
    %global camelotpara does not exist
    clear global camelotpara
end

para.size = length(datastruct.sample);
%%%%%
rand('state',para.seed);
seq = randsample(para.size, para.size);

%take portion of data for parameterization
datai.paradi = seq(1:floor(para.paraportion * para.size));
datai.paracv = cross_validation( para.paracv, length(datai.paradi));

datai.cv = cross_validation(para.cv, para.size);
datai.bt = zeros(para.size, para.bt);
datai.di = (1:para.size)';
for i = 1:para.bt
    datai.bt(:,i) = randsample(para.size, para.size, true);
end

clear i seq para