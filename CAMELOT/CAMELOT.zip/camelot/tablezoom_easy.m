function res = tablezoom_easy(dataset, wlike, zoomtb, genelocdb, varargin)
    %wlike: result from weighLikelihood(like) and wzoomperm (pval);
    %   wlike.wlike
    %zoomtb: zoomtb
    %genelocdb: database of gene locations
    %
    
    
    datastruct = loadData(dataset);
    genelocdb = loadData(genelocdb);
        
    para.stdthres = 0.2;
    
    para = assignpara(para, varargin{:});
    expvi = find(std(datastruct.expression,[],2)> para.stdthres);
                
    res = {'i', 'cond', 'gene', 'final like', 'L(D|E,G)', 'L(E|G)', 'L(G)', ...
        'pval(D,G,E)', 'L rank','pval rank', 'cor','corrank', 'merged region', ...
        'std>.2', 'G', 'dist'};
    
    for condi = 1:length(datastruct.conds)
        curcond = wlike{condi};
        curindexinfo = zoomtb{condi};
        if isempty(curcond), continue; end
        %curcond: [gi li wlike1 wlike2 wlike3 wlikeall wlikerank cor corrank pval prank]        
        %curindexinfo: {[gi li],[logical],{markers},[merged region]}
        [mse mstr closemarker] = regressG(datastruct, condi, curindexinfo(:,3));        
        
        regionStr = mergeMarker(datastruct, curindexinfo(:,4));
        if mod(condi,100) == 0 
            fprintf('processing %d conditions\n',condi);
        end
        %double check
        tmp = cell2mat(curindexinfo(:,1));
        if sum(sum(tmp~=curcond(:,1:2))) > 0
            error('index mismatch, %d\n',condi);
        end        

%         res = {'i', 'cond', 'gene', 'final like', 'L(D|E,G)', 'L(E|G)', 'L(G)', ...
%             'pval(D,G,E)', 'L rank','pval rank', 'cor','corrank', 'source', 'merged region', ...
%             'std>.2', 'G', 'dist'};

        for pairi = 1:size(curcond,1)            
            gmdist = distRegion(closemarker{pairi},...
                genelocdb.loc(strIndexQuery(genelocdb.orf,datastruct.geneid{curcond(pairi,1)}),2:3));
            gmdist = gmdist/1000; %kbp
%             source = sourceStr(curindexinfo{pairi,2});
            if ismember(curcond(pairi,1), expvi)
                vistr = 'True';
            else
                vistr = 'False';
            end
            row = {condi, datastruct.conds{condi}, datastruct.genename{curcond(pairi,1)}, ...
                curcond(pairi,6), ...
                curcond(pairi,3), curcond(pairi,4), curcond(pairi,5), ...
                sprintf('%g',curcond(pairi,10)), curcond(pairi,7), curcond(pairi,11), ...
                curcond(pairi,8), curcond(pairi,9), ...                
                regionStr{pairi}, ...
                vistr, ...
                mstr{pairi}, ...                
                sprintf('%.3f',gmdist)};
            res = [res; row];
        end
    end
    
    
end


function regionstr = mergeMarker(datastruct, mcell)
    %mcell contains the indexes of merged markers
    s = cell(size(mcell,1),1);
    for i = 1:size(mcell,1)
        s{i} = mat2str(mcell{i});
    end
    uregion = unique(s);
    regionstr = cell(size(mcell,1),1);
    for i = 1:size(mcell,1)
        tmps = sprintf('%d: ',strIndexQuery(uregion,s{i}));
        tmps = [tmps datastruct.markers{mcell{i}(1)}];
        for j = 2:length(mcell{i})
            tmps = [tmps ' ' datastruct.markers{mcell{i}(j)}];
        end
        regionstr{i} = tmps;
    end
end

% function sstr = sourceStr(indicator)
%     %indicator: logical, 1x7; gre for lasso, GRE for elastic, G, RG, EG
%     code = {'Q','g','r','e','G','R','E'}; %should agree with zoominb_prepare.m
%     sstr = '';
%     for i = [1 6:9 2:5]
%         if indicator(i)
%             sstr = [sstr code{i}];
%         else
%             sstr = [sstr '-'];
%         end
%     end
% end

function [mse mstr closemarker] = regressG(datastruct, condi, mcell)
    %Calculate mse for all G linked to the condition;
    %mcell is from zoomtb{condi}(:,3), npair(gene,locus) x 1;
    %each pair might come from multiple G, so here we
    %pick the best G for each pair, along with 
    %
    npair = size(mcell,1);
    umi = [];
    for i = 1:npair
        umi = union(umi,mcell{i});
    end
    nmarker = length(umi);
    index = NaN(length(datastruct.markers),1); %index for later retrieval    
    index(umi) = 1:nmarker;
    
    
    y = datastruct.phenotype(condi,:)';
    y(datastruct.outliers{condi}) = NaN;
    vi = ~isnan(y);
    y = zeromean_univar_normalization(y(vi),1);
    X = zeromean_univar_normalization(datastruct.genotype(umi,vi)',1);
    
    umse = (repmat(sum(y.^2),nmarker,1) - ((X'*y).^2) ./ sum(X.^2)'); %column
    umse = umse / sum(vi);
    
    mse = cell(npair,1);
    mstr = cell(npair,1);
    closemarker = cell(npair,1);
    
    for i = 1:npair
        [tmpmse si] = sort(umse(index(mcell{i})));
        mse{i} = sprintf('%f',tmpmse(1));
        mstr{i} = sprintf('%s',datastruct.markers{mcell{i}(si(1))});
        closemarker{i} = mstr{i};
        for j = 2:length(mcell{i})
            if j == 2
                mstr{i} = [mstr{i} sprintf(' (%s',datastruct.markers{mcell{i}(si(j))})];
            else
                mstr{i} = [mstr{i} sprintf(' %s',datastruct.markers{mcell{i}(si(j))})];
            end            
        end
        if length(si) > 1, mstr{i} = [mstr{i} ')']; end       
    end   
end

