function [x] = zeromean_univar_normalization (x, dim)

if nargin < 2, dim = 2; end

if any(isnan(x(:)))
    x = bsxfun(@minus, x, nanmean(x,dim));
    x = bsxfun(@rdivide, x, nanstd(x, 0, dim));
else
    x = bsxfun(@minus, x, mean(x,dim));
    x = bsxfun(@rdivide, x, std(x, 0, dim));    
end
x(isinf(x)) = NaN;