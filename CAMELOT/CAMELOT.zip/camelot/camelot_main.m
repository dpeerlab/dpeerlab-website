
%camelot run
addpath('cross_validation');

global camelotpara
camelotpara.dataset = 'datasample';
camelotpara.algo = {'lasso', 'elastic'}; %elastic net
camelotpara.featureset = {'G', 'RG'}; %genotype; regulator + genotype
camelotpara.numphenocluster = 20; %number of cluster you wish to cluster the phenotype (1 if you don't want cluster the phenotype)
camelotpara.numexpcluster = 60; %number of cluster for expression data

%%%%%% threshold for filtering expression data
%std threshold for regulators
camelotpara.regulatorvalid_stdthres = 0.2; 
%std threshold if no regulators but all transcripts are used in predictor
%pool
camelotpara.expvalid_stdthres = 0.2; 


%threshold for bootstrapping-repeat ratio
camelotpara.btthres = 0.5;
%save bootstrap result or not
camelotpara.savebt = 1;
%%%%%% parameters for dataindex (sampling data for parameterization, cv,
%%%%%% and bt)
camelotpara.paraportion = 0.67; %portion of the data used for parameterization
camelotpara.paracv = 10; %10-fold cv for parameterization
camelotpara.cv = 10; %10-fold for all data to assess models
camelotpara.bt = 200; %200 bootstraps
camelotpara.seed = 135; %random seed, for reproducibility

%========== triangle test parameters ==========
%result of feature set that are subject to triangle test. The feature sets
%here must have expression (eg. 'RG' has R; but 'G' only has genotype, so
%it's not used here)
camelotpara.tri_doset = {'RG'};
%threshold for merging markers according to correlation coefficients
%between genotype of markers; used to preparation of triangle test
camelotpara.tri_mergemarkercorthres = 0.7;
%threshold of "distance of indexes" between markers for marker-merge
camelotpara.tri_mergemarkerindexthres = 10;
%expression dataset used to build all L->R edges that will be tested in
%triangle test
camelotpara.tri_expset = 'expsample';
%number of permutation for triangle test
camelotpara.tri_numperm = 1000000;
%FDR control for significance of R->P edges
camelotpara.tri_FDR = 0.004;
%basic significance threshold (p-val) for L->P and R->P edges; this
%threshold is only to filter edges for triangle test
camelotpara.tri_edgepvalthres = 0.05;
%threshold of correlation coefficient to merge markers; it is a loose
%threshold compared to tri_mergemarkerthres because we want stringent
%comparison between R->P and L->P.
camelotpara.tri_loosemergemarkercorthres = 0.6;



%========== Model revision parameters =========
%base model for revision (must be built in advance; ie. in camelotpara.featureset)
camelotpara.rev_baseset = 'G';
%reference model for revision (must be built in advance; ie. in
%camelotpara.featureset)
camelotpara.rev_refset = 'RG';
%minimum repeat-bootstrap threshold to include the upstream causal markers of
%transcripts that do not pass triangle test
camelotpara.rev_minbtthres = 0.3;




%========== zoom-in parameters ==========
%collect linked loci from these algorithms/models
camelotpara.zoom_algo = {'elastic', 'QTL'};
%collect models that were built with these feature pools
camelotpara.zoom_doset = {'G', 'RG'}; %{genotype, regulator+genotype}
%window used to expand the locus
camelotpara.zoom_window = 30000;
%database containing locations of genes
camelotpara.zoom_genelocdb = 'SGD.mat';
%database of fine resolution markers/genoypes
camelotpara.zoom_detailmarker = 'marker3K.mat';
%marker set used; this should be a field in 'detailmarker'
camelotpara.zoom_markerset = 'impute_dist';
%conservation score; if empty string is provided, uniform prior is used for
%zoom-in score
camelotpara.zoom_consv = 'consv'; 
%known genes, given high prior; empty cell is no known genes
camelotpara.zoom_knowngene = {'GPA1','AMN1','IRA2','DIG1','PHO84','LEU2','MKT1','PHM7','HAP1','ZAP1','RAD5', 'GPB2'};
%number of permutation tests for zoom-in
camelotpara.zoom_numperm = 1000000;




%prepare dataindex
datai = datapreindex(loadData(camelotpara.dataset));
save(sprintf('%sdataindex.mat',camelotpara.dataset), 'datai');

datastruct = loadData(camelotpara.dataset);
if ~isfield(datastruct, 'kgi')
    if camelotpara.numphenocluster < 2
        datastruct.kgi = ones(size(datastruct.phenotype,1),1);
    else
        datastruct.kgi = kmeans(datastruct.phenotype, camelotpara.numphenocluster);
    end
end
clusters = unique(datastruct.kgi);

fprintf('========= Parameter selection and modeling ==========\n');
mkdir(sprintf('%s_models', camelotpara.dataset));
for ai = 1:length(camelotpara.algo)
    for fi = 1:length(camelotpara.featureset) %for each feature set
        for ci = 1:length(clusters) %for each cluster of phenotype
            clusi = clusters(ci);
            %choose parameters for the cluster
            ParaRun(camelotpara.dataset, camelotpara.algo{ai}, camelotpara.featureset{fi}, clusi, 1, 1,'./');
            %run regression modeling on all the phenotypes of the current cluster
            ModelRun(camelotpara.dataset, camelotpara.algo{ai}, camelotpara.featureset{fi}, 'clus',clusi, ...
                sprintf('%s_models/',camelotpara.dataset), ...
                sprintf('./%s_%s_paras.mat',camelotpara.dataset,camelotpara.algo{ai}));
        end
    end
end

%collect all models and save into one file per algorithm
for ai = 1:length(camelotpara.algo)
    models = gatherModel(sprintf('%s_%s', camelotpara.dataset, camelotpara.algo{ai}), sprintf('%s_models/',camelotpara.dataset));
    save(sprintf('%s_%s_model.mat', camelotpara.dataset, camelotpara.algo{ai}), '-struct', 'models');
    fprintf('You may delete model files %s_%s_*.mat under %s_models/.\nThey have been collected and saved in %s_%s_model.mat\n', ...
        camelotpara.dataset, camelotpara.algo{ai}, camelotpara.dataset, camelotpara.dataset, camelotpara.algo{ai});
    clear models
end


%========== Triangle test ==========
% Triangle test is to testing the potential causal relationship between a
% transcript and a phenotype. It is a test designed to stringently filter
% out transcript-regressors if statistical causal relationships cannot be
% established between transcripts and the phenotype

fprintf('========== Prepare for triangle test ==========\n');

%building L->R edges for triangle tests
fprintf('Building all possible L (genotype) -> R (regulator) edges with regression\n');
fprintf('This can take a long time...\n');
expdatastruct = loadData(camelotpara.tri_expset);
if ~isfield(expdatastruct, 'kgi')
    if camelotpara.numexpcluster < 2
        expdatastruct.kgi = ones(size(expdatastruct.phenotype,1),1);
    else
        expdatastruct.kgi = kmeans(expdatastruct.phenotype, camelotpara.numexpcluster);
    end
end
tri_expsetclusters = max(expdatastruct.kgi); 
clear expdatastruct
mkdir(sprintf('%s_models', camelotpara.tri_expset));
for ci = 1:tri_expsetclusters
    fprintf('Modeling cluster %d/%d...\n', ci, tri_expsetclusters);
    %choose parameters for the cluster
    ParaRun(camelotpara.tri_expset, 'elastic', 'G', ci, 1, 1,'./');
    %run regression modeling on all the phenotypes of the current cluster
    ModelRun(camelotpara.tri_expset, 'elastic', 'G', 'clus',ci, ...
        sprintf('%s_models/',camelotpara.tri_expset), ...
        sprintf('./%s_elastic_paras.mat',camelotpara.tri_expset));
end

models = gatherModel(sprintf('%s_elastic', camelotpara.tri_expset), sprintf('%s_models/', camelotpara.tri_expset));
save(sprintf('%s_elastic_model.mat', camelotpara.tri_expset), '-struct', 'models');
clear models

%prepare table for triangle test
fprintf('Building table for triangle test\n');
LRPtb = prepareLRPtb(camelotpara.dataset, camelotpara.tri_expset, 'doset', camelotpara.tri_doset, ...
    'mergemarkercorthres', camelotpara.tri_mergemarkercorthres, ...
    'mergemarkerindexthres', camelotpara.tri_mergemarkerindexthres, ...
    'btthres', camelotpara.btthres);
save(sprintf('%s_LRPtb', camelotpara.dataset), 'LRPtb');

fprintf('Testing significance of R->P and L->P edges\n');
tri = tritest(camelotpara.dataset, LRPtb, camelotpara.tri_numperm, 1:length(LRPtb.cond), false);
save(sprintf('%s_tritest', camelotpara.dataset), 'tri');

fprintf('Testing significance of L->R edges\n');
RLtb = prepareRLtb(camelotpara.dataset);
save(sprintf('%s_RLtb', camelotpara.dataset));

rQTL = QTLSlim(RLtb, camelotpara.tri_numperm, 1:length(RLtb.yi), false);
save(sprintf('%s_rQTL', camelotpara.dataset), 'rQTL');
clear RLtb

fprintf('Analyzing results from triangle test\n');
results.triangle = tableChain(camelotpara.dataset, tri, rQTL, LRPtb, ...
    'fdrqc', camelotpara.tri_FDR, 'doset', camelotpara.tri_doset, ...
    'loosemergemarkercorthres', camelotpara.tri_loosemergemarkercorthres, ...
    'mergemarkerindexthres', camelotpara.tri_mergemarkerindexthres, ...
    'edgepvalthres', camelotpara.tri_edgepvalthres);
clear tri rQTL LRPtb

fprintf('========= Revising regression models ==========\n');

[revmodel.revtb revmodel.mse revmodel.action revmodel.pred] = crystalball(camelotpara.dataset, ...
    camelotpara.rev_baseset, camelotpara.rev_refset, ...
    'mergemarkercorthres', camelotpara.tri_mergemarkercorthres, ...
    'mergemarkerindexthres', camelotpara.tri_mergemarkerindexthres, ...
    'btthres', camelotpara.btthres, ...
    'minbtthres', camelotpara.rev_minbtthres, ...
    'edgepvalthres', camelotpara.tri_edgepvalthres, ...
    'loosemergemarkercorthres', camelotpara.tri_loosemergemarkercorthres, ...
    'doset', camelotpara.tri_doset);

results.model = tablefinalmodel(camelotpara.dataset, revmodel);
clear revmodel

%========== Zoom-in ==========
% Zoom-in is a post-process of modeling. It is not included in the final
% regression modeling process. Zoom-in is a Bayesian scoring function to
% prioritize genes in any chromosomal region that links to a phenotype. 

fprintf('========== Prepare for zoom-in ==========\n');
[qtl.R2 qtl.mse qtl.p1] = QTLinkage(camelotpara.dataset, [], 1, length(datastruct.conds));
save(sprintf('%s_QTL.mat',camelotpara.dataset), '-struct', 'qtl');
clear qtl

% should provide your own filter here; if no filter, set snp = []
%snp = []; %querySNP(datastruct.geneid, {'csnp','nsnp'});
%snp = ~(snp(:,1)==0 & snp(:,2)==0);
zoomtb = zoominb_prepare(camelotpara.dataset, camelotpara.zoom_window, ...
    'algo', camelotpara.zoom_algo, 'doset', camelotpara.zoom_doset, ...
    'btthres', camelotpara.btthres, 'genelocdb', camelotpara.zoom_genelocdb, ...
    'detailmarker', camelotpara.zoom_detailmarker);%, 'SNPfilter', snp);
save(sprintf('%s_zoomtb', camelotpara.dataset), 'zoomtb');


%zoom-in likelihood
zoomlike = weightLikelihood(camelotpara.dataset, zoomtb, ...
    'detailmarker', camelotpara.zoom_detailmarker, 'markerset', camelotpara.zoom_markerset, ...
    'consv', camelotpara.zoom_consv, 'known_gene', camelotpara.zoom_knowngene);

zoomperm = zoomwperm(camelotpara.dataset, zoomlike, zoomtb, 1:length(zoomtb), camelotpara.zoom_numperm, false, ...
    'detailmarker', camelotpara.zoom_detailmarker, 'markerset', camelotpara.zoom_markerset);

zoomlike = combineperm(zoomlike, zoomperm);
save(sprintf('%s_zoomlike', camelotpara.dataset), 'zoomlike');

results.zoom = tablezoom_easy(camelotpara.dataset, zoomlike.wlike, zoomtb, ...
    camelotpara.zoom_genelocdb, 'stdthres', camelotpara.regulatorvalid_stdthres);

clear global *