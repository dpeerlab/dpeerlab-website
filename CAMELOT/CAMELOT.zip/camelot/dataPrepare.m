function [data] = dataPrepare(datastruct, fset, clusi, clusfield, indexonly)
    %prepare data for modeling, paratemterization, including
    %1. forming feature set from either {'R','G','RG', 'EG'}
    %2. prepare names for each feature
    %3. remove outliers
    %4. normalization
    %datastruct: Noel    
    %fset: {'R','G','RG'...}
    %clusi: index of cluster in growth data; if -1 then take all y
    %clusfield: "clus index" field in datastruct
    %indexonly: {true, false}, return x index only
    %
    %return
    %data.x, data.y, data.xname    
    %data.R: vector of indice in data.x (also applied to E)
    %data.G: vector of indice in data.x
    
    global camelotpara
    if ~isempty(camelotpara)        
        regvalidthres = camelotpara.regulatorvalid_stdthres;
        expvalidthres = camelotpara.expvalid_stdthres;
        clear camelotpara
    else
        clear global camelotpara
        regvalidthres = 0.2;
        expvalidthres = 0.25;
    end
        
    
    if nargin < 5, indexonly = false; end
    if nargin < 4, clusfield = 'kgi'; end
    if nargin < 3, clusi = -1; end %take all conditions
            
    if indexonly
        data = returnIndex(datastruct, fset, regvalidthres, expvalidthres);
        return
    end
    
    if isfield(datastruct, 'expression')
        expvalid = find( std(datastruct.expression, [], 2) > regvalidthres);
        if isfield(datastruct, 'include') %include some specific genes
            expvalid = union(expvalid, datastruct.include);
        end
    else
        expvalid = '';
    end
    
    %prepare observations        

    data.y = datastruct.phenotype;
    ncond = size(datastruct.phenotype, 1);
    if isfield(datastruct, 'outliers')
        for i = 1:ncond
            data.y(i, datastruct.outliers{i}) = NaN;
        end
    end
    if clusi ~= -1 %take only conditions in cluster i
        data.y = data.y(datastruct.(clusfield)==clusi,:);
    end
    data.y = zeromean_univar_normalization(data.y);

    
    %prepare regressors
    data.x = [];
    data.xname = {};
    data.R = [];
    data.G = [];
    data.gi = [];
    if ~isempty(strfind(fset, 'R'))
        vi = intersect(datastruct.regulators, expvalid);
        data.gi = vi;
        data.R = (size(data.x,1)+1 : size(data.x,1)+length(vi))';
        data.x = [data.x; datastruct.expression(vi,:)];
        data.xname = [data.xname; datastruct.genename(vi)];        
    end
    if ~isempty(strfind(fset, 'E'))
        vi = find( std(datastruct.expression, [], 2) > expvalidthres);
        data.gi = vi;
        data.R = (size(data.x,1)+1 : size(data.x,1)+length(vi))';
        data.x = [data.x; datastruct.expression(vi,:)];
        data.xname = [data.xname; datastruct.genename(vi)];
    end
    if ~isempty(strfind(fset, 'V'))
        data.gi = expvalid;
        data.R = (size(data.x,1)+1 : size(data.x,1)+length(expvalid))';
        data.x = [data.x; datastruct.expression(expvalid,:)];
        data.xname = [data.xname; datastruct.genename(expvalid)];
        data.orf = datastruct.geneid(expvalid);
    end
    if ~isempty(strfind(fset, 'A'))      
        data.R = (size(data.x,1)+1 : size(data.x,1)+length(datastruct.genename))';
        data.x = [data.x; datastruct.expression];
        data.xname = [data.xname; datastruct.genename];
        data.orf = datastruct.geneid;
    end
    if ~isempty(strfind(fset, 'G'))
        data.G = (size(data.x,1)+1 : size(data.x,1)+size(datastruct.genotype,1))';
        data.x = [data.x; datastruct.genotype];
        data.xname = [data.xname; datastruct.markers];
    end
    data.x = zeromean_univar_normalization(data.x);   
end


function data = returnIndex(datastruct, fset, regvalidthres, expvalidthres)
    if isfield(datastruct, 'expression')
        expvalid = find( std(datastruct.expression, [], 2) > regvalidthres);
        if isfield(datastruct, 'include') %include some specific genes
            expvalid = union(expvalid, datastruct.include);
        end
    else
        expvalid = '';
    end
    
    %prepare regressor indexes
    data.gi = [];    
    data.R = [];
    data.G = [];
    x = [];
    if ~isempty(strfind(fset, 'R'))
        vi = intersect(datastruct.regulators, expvalid);
        data.gi = vi;
        data.R = (size(x,1)+1 : size(x,1)+length(vi))';
        x = [x; vi];
    end
    if ~isempty(strfind(fset, 'E'))
        vi = find( std(datastruct.expression, [], 2) > expvalidthres);
        data.gi = vi;
        data.R = (size(x,1)+1 : size(x,1)+length(vi))';      
        x = [x; vi];
    end
    if ~isempty(strfind(fset, 'V'))
        data.gi = expvalid;
        data.R = (size(x,1)+1 : size(x,1)+length(expvalid))';    
        x = [x; data.gi];
    end
    if ~isempty(strfind(fset, 'A'))      
        data.gi = (1:length(datastruct.genename))';
        data.R = (size(x,1)+1 : size(x,1)+length(datastruct.genename))';
        x = [x; data.gi]; 
    end
    if ~isempty(strfind(fset, 'G'))
        data.G = (size(x,1)+1 : size(x,1)+size(datastruct.genotype,1))';      
        x = [x; data.gi];
    end        
end
