function [res] = tritest(dataset, LRPtb, nruns, runindex, tosave)
    %test R->P and L->P
    %dataset: name of dataset
    %LRPtb: "linked" from prepareLRPtb.m
    %runindex: run index (1~length(LRPtb.cond))
    %nrun: number of permutation runs
    %
    %res
    
    if ischar(LRPtb)
        linkfn = LRPtb;
        LRPtb = load(LRPtb);
        LRPtb = LRPtb.LRPtb;
    end
    
    if nargin < 5, tosave = false; end
    if nargin < 4, runindex = 1:length(LRPtb.cond); end
    if nargin < 3, nruns = 1000; end
    
    if ischar(tosave)
        fnheader = tosave;
        tosave = true;
    else
        fnheader = '';
    end
            
    datastruct = loadData(dataset);
    data = dataPrepare(datastruct, 'AG');
    
    t = cputime();
    nruncond = length(runindex);
    res = cell(nruncond,1);
    for i = 1:nruncond
        condi = LRPtb.cond(runindex(i));        
        
        trait = data.y(condi,:);
        genotype = data.x(data.G,:);
        expression = data.x(data.R,:);
        
        vi = ~isnan(trait)';
        Llink = LRPtb.structure{runindex(i),1};
        Rlink = LRPtb.structure{runindex(i),2};
        nL = size(Llink,1); %number of merged region
        
        res{i}.Rtest = cell(nL,1);
        %get best-correlated marker in each merged region
        mi = zeros(nL,1);
        for j = 1:nL
            if length(Llink{j}) == 1
                mi(j) = Llink{j};
            else
                c = corr(trait(vi)',genotype(Llink{j},vi)');
                [m genoi] = max(abs(c));
                mi(j) = Llink{j}(genoi);
            end
            
            [pval mse] = permTestGrp(nruns, -1, 'tailL', @singOlsRegmtx, true,...
                expression(Rlink{j},vi)', genotype(mi(j),vi)', trait(vi)');
            res{i}.Rtest{j} = [pval mse];
        end
        %test L->P
        [pval mse] = permTest(nruns, -1, 'tailL', @singOlsRegmtx, true, ...
            genotype(mi,vi)', trait(vi)');
        
                        
        res{i}.condi = condi;
        res{i}.region = Llink;
        res{i}.locus = mi;
        res{i}.regulator = Rlink;
        res{i}.Ltest = [pval mse];
    end    
    fprintf('tritest: %f\n',cputime()-t);
    if tosave
        if exist('linkfn','var')
            fname = sprintf('%s%s_%s_tritest_%dK_%03d',fnheader,dataset,...
                linkfn, floor(nruns/1000),runindex(1));
        else
            fname = sprintf('%s%s_tritest_%dK_%03d',fnheader,dataset,...
                floor(nruns/1000),runindex(1));
        end
        save(fname, 'res');
    end
end