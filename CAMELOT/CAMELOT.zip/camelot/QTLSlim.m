function [res] = QTLSlim(RLtb, nrun, runindex, tosave)
    %For each trait, only test certain (potential) loci
    %
    %RLtb: possible links L->R for current dataset; generated from prepareRLtb.m
    %   dataset: {'reg'}
    %   ytype: {'growth'}, trait type
    %   xtype: {'marker'}, locus
    %   yi: index of y in dataset
    %   xi: index of x in dataset
    %
    %nrun: #run for permutation test (on fitting mse); if -1, no
    %   permutation test
    %
    %tosave: to save file or not, if trait is a matrix (not string), tosave
    %   will be set to false and no file will be saved.
    %
    %return:
    %R2: R2 statistics
    %mse: mean squared error
    %p1: H0: if coefficient of a locus is 0
    %p2: permutation p-val
    %
    
    if ischar(RLtb)
        s = load(RLtb);
        RLtb = s.RLtb;
        clear s
    end
            
    s = loadData(RLtb.dataset);
    data = dataPrepare(s, 'AG');
    
    
    switch lower(RLtb.ytype)
        case 'reg'
            trait = data.x(data.R,:)';
        otherwise
            error('Unknown ytype %s.\n',RLtb.ytype);
    end
    trait = trait(:,RLtb.yi);
    genotype = data.x(data.G,:)';
                        
    [nsample ntrait] = size(trait);
    [nobs nlocus] = size(genotype);
    if nsample ~= nobs
        error('different sample size in trait and genotype\n');
    end
    
    if nargin < 2, nrun = 1000; end
    if nargin < 3, runindex = 1:ntrait; end
    if nargin < 4, tosave = true; end      
    
    if ischar(tosave)
        fnheader = tosave;
        tosave = true;
    else
        fnheader = '';
    end
    
    nruncond = length(runindex);
    fprintf('running QTL for %d traits with %d loci, perm %d runs\n',...
        nruncond, nlocus, nrun);
        
    t = cputime();
    
    R2 = cell(nruncond, 1);
    mse = cell(nruncond, 1);
    p1 = cell(nruncond, 1);
    p2 = cell(nruncond, 1);
    
    %fast version, approx, but diff is very small    
    for runi = 1:nruncond
        ti = runindex(runi);
        y = trait(:,ti); %data were standardized already, no missing values
        X = genotype(:,RLtb.xi{ti});
        
        ntest = length(RLtb.xi{ti});
        
        beta = (X' * (y)) ./ (sum(X.^2)'); %column
        nu = nsample-2;
        p = 1;
        yhat = repmat(beta',nsample,1).*X; %nsample x ntest
        ess = sum((yhat-repmat(y,1,ntest)).^2); %row
        tss = sum((y-mean(y)).^2); %scalar
        rss = sum((yhat-mean(y)).^2); %row
        s2 = ess/nu; %row
        F = rss/p./s2; %row
        p1{runi} = 1 - fcdf(F,1,nu); %row
        mse{runi} = ess/nsample;
        R2{runi} =  rss./tss;
        %permutation test
        if nrun ~= -1
            p2{runi} = permTest(nrun, -1, 'tailL', @singOlsRegmtx, true, X, y);            
        end
    end

    res.R2 = R2;
    res.mse = mse;
    res.p1 = p1;
    res.p2 = p2;
    res.yi = RLtb.yi;
    res.xi = RLtb.xi;
    res.dataset = RLtb.dataset;
    res.ytype = RLtb.ytype;
    res.xtype = RLtb.xtype;
    res.runindex = runindex;
    
    fprintf('time: %g\n',cputime()-t);   
    if tosave        
        if nrun ~= -1
            fn = sprintf('%s_rQTLslim_%dK_%03d.mat',RLtb.dataset, floor(nrun/1000), runindex(1));
        else
            fn = sprintf('%s_rQTLslim_%03d.mat',RLtb.dataset,runindex(1));
        end
        rQTL = res;
        save([fnheader fn], 'rQTL');
    end
    

end

                    
    

