function linked = prepareLRPtb(dataset, expset, varargin)
    %generate file for tritest
    %dataset = 'ethanf01';
    %expset = 'ethanexp'; %to load L->R model

    para.doset = {'R','E','RG','EG'};
    para.mergemarkercorthres = 0.7;
    para.mergemarkerindexthres = 10;
    para.btthres = 0.5;
    
    para = assignpara(para, varargin{:});

    fset = {'R','D','E','RG','DG','EG'};
    datastruct = loadData(dataset);
    ncond = length(datastruct.conds);
    condi = (1:ncond)';

    expdatastruct = loadData(expset);

    
    gindexstruct = cell(ncond,1); %index of genes (index to datastruct.geneid)
    
    for i = 1:ncond
        %index to datastruct.geneid, logical indicator of fset, index to
        %expdatastruct.ORFs
        gindexstruct{i} = cell(0,3);     
    end
    model = load(sprintf('%s_elastic_model',dataset));
    
    %map datastruct.geneid to expdatastruct.conds
    if length(unique(expdatastruct.conds)) == length(expdatastruct.conds)
        iInExp = strIndexQuery(expdatastruct.conds, datastruct.geneid);
    else
        fprintf('overlap gene id in the data! Sequential mapping\n');
        iInExp = NaN(length(datastruct.geneid),1);
        for i = 1:length(datastruct.geneid)
            mapgi = strmatch(datastruct.geneid{i}, expdatastruct.conds);
            if isempty(mapgi)
                iInExp(i) = -1;
            elseif length(mapgi) == 1
                iInExp(i) = mapgi;
            else
                mapgi = min(setdiff(mapgi, iInExp));
                if isempty(mapgi)
                    iInExp(i) = -1;
                else
                    iInExp(i) = mapgi;
                end
            end                
        end
    end
    
    if sum(iInExp==-1) > 0
        warning('Cannot find %d genes; these genes will be skipped.',sum(iInExp==-1));
    end
    
    %collect transcripts and their indexes in expdatastruct (to get L->R)
    for fi = 1:length(fset)
        if ~ismember(fset{fi}, para.doset)
            continue;
        end
                
        data = dataPrepare(datastruct, fset{fi});
        
        indicator = false(1, length(fset));
        indicator(fi) = true;
        sub = model.(sprintf('%s_001',fset{fi}));
        for i = 1:ncond
            if isempty(sub{i}), continue; end
            geneindex = data.gi(intersect(data.R, find(sub{i}.btratio>=para.btthres)));
            expindex = iInExp(geneindex);
            for j = 1:length(geneindex)
                if expindex(j) == -1, continue; end
                rowi = find( cell2mat(gindexstruct{i}(:,1)) == geneindex(j) );
                if ~isempty(rowi)
                    gindexstruct{i}{rowi,2} = gindexstruct{i}{rowi,2} | indicator;
                else
                    gindexstruct{i}{end+1,1} = geneindex(j);
                    gindexstruct{i}{end,2} = indicator;
                    gindexstruct{i}{end,3} = expindex(j);
                    if length(datastruct.geneid)==length(expdatastruct.conds) && geneindex(j)~=expindex(j)
                        fprintf('geneindex ~= expindex, %d %d %d\n',fi,i,j);
                    end
                end
            end
        end
    end
    clear model sub
    
    %get L -> R
    regmodel = load(sprintf('%s_elastic_model',expset));
    regmodel = regmodel.G_001;

    res = cell(ncond,2);
    for i = 1:ncond
        fi = cell2mat(gindexstruct{i}(:,1));
        expi = cell2mat(gindexstruct{i}(:,3));
        markerindex = []; %marker index
        regulatorindex = {}; %regulator
        for j = 1:length(fi)
            if expi(j)==-1 %didn't find in regmodel
                continue
            end
            if isempty(regmodel{expi(j)})
                continue
            end
            mi = find(regmodel{expi(j)}.btratio>=para.btthres);
            %if no genotype linked, pick at least the best one (two)
            if isempty(mi)            
                [tmp si] = sort(full(regmodel{expi(j)}.btratio),'descend');
                mi = si(1:2); %take the top two
            end
            for k = 1:length(mi) 
                if ~ismember(mi(k), markerindex)
                    markerindex = [markerindex; mi(k)];
                    regulatorindex = [regulatorindex; {fi(j)}];                                        
                else
                    tmpi = find(markerindex == mi(k));
                    regulatorindex{tmpi} = [regulatorindex{tmpi} fi(j)];
                end
            end
        end
        res{i,1} = markerindex;
        res{i,2} = regulatorindex;
    end
    clear regmodel

    indexes = mergeMarker(datastruct.genotype',para.mergemarkercorthres, ...
        1:size(datastruct.genotype,1), para.mergemarkerindexthres);
    fprintf('merge markers by corr >= %g\n', para.mergemarkercorthres);
    clear datastruct
    
    %now in res, each row is a condition with res{i,1} = [marker_index],
    %res{i,2} = regulator indexes linked to each marker
    %merge the list (to res2) according to merged markers
    res2 = cell(size(res));
    for i = 1:ncond
        if ~isempty(res{i,1})
            mergi = indexes(res{i,1});
            ui = unique(mergi);
            tmp = {};
            for j = 1:length(ui) %for each merged region
                k = find(mergi==(ui(j)));
                mergf = [];
                for tmpi = k'
                    mergf = union(mergf, res{i,2}{tmpi});
                end
                if ~isempty(mergf)  
                    tmp{end+1,1} = res{i,1}(k)'; %marker index
                    tmp{end,2} = mergf;
                end
            end
            res2{i,1} = tmp(:,1); %marker indexes grouped by regions
            res2{i,2} = tmp(:,2); %regulator indexes linked to the regions
        end
    end
    res = res2;
    %now res is #cond x 2, res{i,1} is merged locus, res{i,2} contains
    %regulators linked to the merged region
    %collect only nonempty
    tmpindex = find(~cellfun(@isempty, res(:,1)));
    linked.cond = condi(tmpindex);
    linked.structure = res(tmpindex,:);
    linked.gindexsource = gindexstruct(tmpindex,:); 
    linked.note = sprintf('structure{cond,1}=marker indexes in a merged region\n');
    linked.note = sprintf('%sstructure{cond,2}=gene indexes linking to the merged region\n',linked.note);
    linked.note = sprintf('%sgindexsource{condi}(,:)={gene index in models, sources of models}\n',linked.note);
    
end
