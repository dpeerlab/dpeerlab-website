function res = parseText(fn, varargin)
    %fn: file name
    %varargin:
    %   'skip': number of lines to skip at the beginning of the file
    %       (comments etc)
    %   'colname': {true, false}; def=false;
    %   'rowname': {true, false}; def=false; if true, rownames are extracted
    %       from first column
    %   'ncol': number of columns if known
    %   'delimiter': default=tab
    %   'numeric': if the text body is numeric (except for the rowname, if
    %       exists); default=false;
    %   'nrowname': default = 0; number of columns in the beginning should
    %       be read as the "name" for rows
    %   'ncolname': default = 0; number of rows in the the beginning of the
    %       file should be read as the "name" for columns
    %
    %Note: to make sure it reads file correctly, put NaN for ''
    %
    %return:
    %   res.rowname, if rowname=true
    %   res.colname, if colname=true
    %   res.text
    %
    
    %default
    delimiter = 9; %tab
    colname = false;
    rowname = false;
    skip = 0;
    ncol = 0;
    numeric = false;
    nrowname = 0;
    ncolname = 0;
    
    i = 1;
    while i < length(varargin)
        switch lower(varargin{i})
            case {'colname','rowname','numeric'}
                eval(sprintf('%s = logical(%d);',varargin{i},varargin{i+1}));
            case {'skip','ncol', 'nrowname', 'ncolname'}
                eval(sprintf('%s = %d;',varargin{i},varargin{i+1}));
            case {'delimiter'}
                if strcmp(varargin{i+1},'\t')
                    delimiter = 9;
                else
                    delimiter = varargin{i+1};
                end
            otherwise
                error('Unknown option %s.\n',varargin{i});
        end
        i = i + 2;
    end
    
    if rowname && nrowname == 0
        nrowname = 1;
    end
    if colname && ncolname == 0
        ncolname = 1;
    end
    if nrowname >= 1 && ~rowname
        rowname = true;
    end
    if ncolname >= 1 && ~colname
        colname = true;
    end
    
    fid = fopen(fn);    
    %skip lines if any
    i = 0;
    while i < skip
        line = fgetl(fid);
        i = i + 1;
    end
    if colname
        res.colname = cell(0, ncolname);
        for i = 1:ncolname
            hline = fgetl(fid);            
            [res.colname{1, i} t] = strtok(hline,delimiter);
            nextc = 2;
            while ~isempty(t) %length(t) > 0
                [res.colname{nextc, i} t] = strtok(t, delimiter);
                nextc = nextc + 1;
            end            
        end
    end
    
    if numeric
        formattail = ' %f';     res.text = [];
    else
        formattail = ' %s';     res.text = {};
    end
%     if rowname || ~numeric %at least the file has one column
%         format = '%s';
%     else
%         format = '%f';
%     end
    format = '';
    if ncol == 0
        fpos = ftell(fid);
        line = fgetl(fid);
        offset = fpos - ftell(fid);        
        fseek(fid, offset, 'cof');
        %decide the number of columns        
        [a t] = strtok(line, delimiter);
        if ~isempty(a) %length(a) > 0            
            ncol = ncol + 1;
        end        
        while ~isempty(t) > 0 
            [a t] = strtok(t, delimiter);
            %format = [format formattail];
            ncol = ncol + 1;
        end
    %else        
    %    for i = 2:ncol
    %        format = [format formattail];
    %    end
    end
    for i = 1:nrowname
        format = [format ' %s'];
    end
    for i = 1:ncol-nrowname
        format = [format formattail];
    end
        
    if isscalar(delimiter), delimiter = '\t'; end
    text = textscan(fid, format, 'delimiter',delimiter);    
    fclose(fid);
    
    if rowname
        res.rowname = cell(length(text{1}), nrowname);
        for i = 1:nrowname
            res.rowname(:,i) = text{i};
        end
        text = text(nrowname+1:end);
    end
    
    for i = 1:length(text)
        res.text(:,i) = text{i};
    end

    
    
    