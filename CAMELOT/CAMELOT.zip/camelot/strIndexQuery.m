function [indices] = strIndexQuery(cells, queries)
%this function only return the first one searched
%that means if more than one entry is in the data pool,
%it will only return the first occurence

    if ~iscell(queries)
        queries = {queries};
    end
    %t = cputime();
    indices = [];
    for i = 1:length(queries)

        j = strmatch(queries{i}, cells, 'exact');
        if isempty(j)
            indices = [indices; -1];
        else
            indices = [indices; j(1)];
        end
    end
    %fprintf('time:%f\n',cputime()-t);
end