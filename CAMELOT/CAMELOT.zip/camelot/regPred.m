function [yhat] = regPred(X, betas, model)
    %a simple computation for prediction
    %X: #sample * #feature
    %betas: #feature * #model
    %model: struct
    %model.ybar: mean of observed y, 1 * #model or scalar
    %model.normx: norm of observed x, 1 * #feature
    %model.meanx: mean of observed x_j, 1 * #feature
    

    nSample = size(X,1);

    
    %normalization
    if isfield(model, 'meanx')
        scX = X - repmat(model.meanx, nSample, 1);
        scX = scX ./ repmat(model.normx, nSample, 1);
    else
        scX = X;
    end
    
    if isscalar(model.ybar)  
        yhat = scX * betas + model.ybar;
    else
        yhat = scX * betas + repmat([model.ybar],nSample,1);
    end
end