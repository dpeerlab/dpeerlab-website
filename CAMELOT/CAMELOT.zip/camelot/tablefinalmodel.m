function res = tablefinalmodel(dataset, revmodel)
    
    dataset = loadData(dataset);
    
    ncond = length(dataset.conds);
    res = cell(ncond+1, 5);
    res(1,:) = {'i','cond','gene','marker','r'};
    
    for i = 1:ncond
        res{i+1, 1} = sprintf('%d', i);
        %res{i+1, 2} = sprintf('%s', dataset.drug{i});
        res{i+1, 2} = sprintf('%s', dataset.conds{i});
        res{i+1, 3} = predstr(dataset.genename, revmodel.revtb{i,1});
        res{i+1, 4} = predstr(dataset.markers, revmodel.revtb{i,2});
        res{i+1, 5} = sprintf('%.2f', corr(dataset.phenotype(i,:)', revmodel.pred(i,:)', 'rows', 'pairwise'));
    end
    
end

function s = predstr(pool, index)
    s = '';
    if ~isempty(index)
        s = pool{index(1)};
        for i = 2:length(index)
            s = sprintf('%s, %s',s, pool{index(i)});
        end
    end
end