function datastruct = loadData(dataset)

    if isempty(strfind(dataset, '.mat'))
        dataset = [dataset '.mat'];
    end
    
    if ~exist(dataset, 'file')
        error('loadData(): cannot find %s under current directory', dataset);
    end

    s = load(dataset);
    fd = fieldnames(s);
    if length(fd) > 1
        warning('more than one field in %s.mat',dataset);
    end

    datastruct = s.(fd{1});
    
