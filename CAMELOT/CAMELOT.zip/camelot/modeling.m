function [res] = modeling(X, y, para)
    %X: #observation * #regressor
    %y: #observation * #series; 
    %   #series = 1 for 'model' mode, each time return a model
    %   #series = total conditions for 'para' model, for uni para set
    %para: from paraPrepare
    %
    %return
    %'para' mode:    
    % res.err: mse for each series of y; npara1 * npara2   
    % res.minerr: min mse
    % res.(para1): para1 for min error
    % res.(para2): para2 for min error
    %
    %'model' mode:
    % res.para: para used    
    % res.yhat: cv yhat from OLS
    % res.err: mse from OLS
    % res.btratio: repeat ratio for each feature
    % res.btbeta: save for the future (if para.savebt = 1)

    switch para.mode
        case 'para'
            res = cvParaRun(X(para.di,:), y(para.di,:), para);
        case 'model' %bt first and then cvOLS            
            res = btRun(X(para.di,:), y(para.di,:), para);            
            res = olsRun(X(para.di,:), y(para.di,:), para, res); 
            res.para = para; %copy para
        otherwise
            error('modeling: unknown mode %s', para.mode);
    end

end

function [res] = olsRun(X, y, para, btres)
    % X: #sample * #feature
    % y: #sample * 1
    % para: from paraPrepare
    % btres: from btRun
    %
    % return
    % res.btratio: repeat ratio for each feature
    % res.yhat: cv yhat from OLS
    % res.err: mse from OLS
    % res.btbeta: save for the future
    % res.R2: R2 = corr(yhat,y)^2
    % res.sR2: spearman R2 = spearman corr(yhat,y)^2
    % res.oppsratio: ratio of opps sign in btbeta
    
    nBoots = size(para.bt,2);
    if ~isfield(para, 'btthre')
        para.btthre = 0.5;
    end
    [nSamples, nSeries] = size(y);    
    nFeatures = size(X,2);
    
    res.btratio = sparse(zeros(nFeatures, nSeries));
    res.oppsratio = sparse(zeros(nFeatures, nSeries));
    if ~isempty(para.cv)
        res.yhat = NaN(nSamples, nSeries);
        res.err = NaN(nSeries,1);
        res.R2 = NaN(nSeries,1);
        res.sR2 = NaN(nSeries,1);
    end
    
    for si = 1:nSeries
        counts = sum(btres.beta(:,(si-1)*nBoots+1 : si*nBoots) ~= 0, 2);
        res.btratio(:,si) = counts / nBoots;
        np = sum(btres.beta(:,(si-1)*nBoots+1 : si*nBoots) > 0, 2);
        nn = sum(btres.beta(:,(si-1)*nBoots+1 : si*nBoots) < 0, 2);
        res.oppsratio(:,si) = min([np,nn],[],2) ./ max([np,nn],[],2);
        if isempty(para.cv) %no cv matrix
            continue
        end
        fi = find(res.btratio(:,si) >= para.btthre);
        if ~isempty(fi)
            [res.err(si) res.yhat(:,si)] = cvOLS(y(:,si)', X(:,fi)', ...
                para.cv);
            res.R2(si) = corr(res.yhat(:,si), y(:,si), 'rows','pairwise')^2;
            res.sR2(si) = corr(res.yhat(:,si), y(:,si), 'rows','pairwise',...
                'type','Spearman')^2;
        end
    end    
    if isfield(para, 'savebt')
        if para.savebt, res.btbeta = btres.beta; end
    end
end

function [res] = btRun(X, y, para)
    % X: #sample * #feature
    % y: #sample * 1
    % para: from paraPrepare
    %
    % if paras for algorithm are vectors, return the best model
    % otherwise, paras are scalars and are used to do cv directly
    %
    % return
    % res.beta: beta for bootstrap runs, #regressor * (#Series*#BT)

    [nSamples, nSeries] = size(y);
    nFeatures = size(X,2);
    nBoots = size(para.bt,2);

    res.beta = sparse(zeros(nFeatures, nSeries*nBoots));
   
    t = cputime();
    for si = 1 : nSeries
        for fold = 1 : nBoots
            %get bootstrapping features and targets!!!!!
            bootX = X(para.bt(:,fold), :);
            booty = y(para.bt(:,fold), si);

            %exclude NaN strains
            valid_strain = find(isnan(booty)==0);

            switch para.algo
                case 'lasso'
                    model = larsENL1(bootX(valid_strain,:), ...
                        booty(valid_strain), 0, 0, 0, para.L1);
                    res.beta(:,(si-1)*nBoots+fold) = model.beta;
                case 'elastic'                    
                    model = larsENL1(bootX(valid_strain,:), ...
                        booty(valid_strain), para.lambda, 0, 0, para.L1);
                    res.beta(:,(si-1)*nBoots+fold) = model.beta;
                case 'step'
                    model = stepwisefit(bootX(valid_strain,:), ...
                        booty(valid_strain),'display','off');
                    res.beta(:,(si-1)*nBoots+fold) = model;
            end            
        end
    end    
    fprintf('btRun, time elapsed: %f\n',cputime()-t);   
end


function [res] = cvParaRun(X, y, para)
    % X: #sample * #feature
    % y: #sample * #condition !!!!! different from modeling process
    % para: from paraPrepare
    %
    % return
    % res.err: mse for each series of y; npara1 * npara2   
    % res.minerr: min mse
    % res.(para1): para1 for min error
    % res.(para2): para2 for min error
    %
    % we only care about the error here since we are looking for a set of
    % parameters for all conditions
        
    [nSamples, nSeries] = size(y);        
    
    [para1, para2, parastr] = paraAlgoExtract(para);
    npara1 = length(para1);
    npara2 = length(para2);
    
    %test error for CV
    res.err = zeros(npara1,npara2);    
    nskip = 0;
    
    %tmpMtx for yhat
    tmpMtx = NaN(nSamples, npara1*npara2);
    t = cputime();
    for si = 1 : nSeries       
        tmpMtx(:,:) = NaN; %clean matrix
        %filter out NaN
        valid_strain = find(isnan(y(:,si))==0);                              
        for fold = 1 : size(para.cv,1)
            [trIndx, ttIndx] = training_test_indices (fold, para.cv);            
            trIndx = intersect(valid_strain, trIndx); %exclude NaN strains
            ttIndx = intersect(valid_strain, ttIndx);            
            switch para.algo
                case 'lasso' %don't care about para2 (lambda)
                    %model = lassoRun(X(trIndx,:), y(trIndx,si), para1);
                    model = larsENL1(X(trIndx,:), y(trIndx,si),...
                              0, 0, false, para1);    
                    tmpMtx(ttIndx, 1:npara1) = ...
                        regPred(X(ttIndx,:), model.beta, model);
                case 'elastic'
                    %model.beta contains #feature * #model(#para1:L1)
                    for para2i = 1:npara2
                        model = larsENL1(X(trIndx,:), y(trIndx,si),...
                            para2(para2i), 0, false, para1);    
                        tmpMtx(ttIndx,(para2i-1)*npara1+1:para2i*npara1) = ...
                            regPred(X(ttIndx,:), model.beta, model);                        
                    end            
            end           
        end
        residual = tmpMtx - repmat(y(:,si), 1, npara1*npara2);
        err = nanmean(residual.^2); %1*(npara1*npara2)
        if length(find(isnan(err))) > 1
            nskip = nskip + 1;
        else
            res.err = res.err + reshape(err, npara1, npara2);
        end
    end
    %take the mean
    res.err = res.err / (nSeries-nskip);
    [tmp, i] = nanmin(res.err);
    [res.minerr, j] = nanmin(tmp);    
    res.(parastr{1}) = para1(i(j));
    res.(parastr{2}) = para2(j);

    fprintf('cvParaRun, time elapsed: %f\n',cputime()-t);   
end

