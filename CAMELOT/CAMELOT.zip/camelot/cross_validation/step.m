function [res] = step(input)
if( input >= 0 )
   res = 1;
else
   res = 0;
end
