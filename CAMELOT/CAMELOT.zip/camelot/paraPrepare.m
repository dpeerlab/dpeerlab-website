function [para] = paraPrepare(dataset, mode, algo, fset, clusi, parafn, parakey)
    %prepare parameters needed for modeling for paramterization (selection)    
    %dataset = string, name of the dataset
    %mode = {'model', 'para'} for modeling or paramerization
    %algo = {'sing', 'lasso', 'elastic'}
    %fset = {'R','G','RG'}
    %clusi = index of cluster index in phenotype
    %parafn is to get paramters from previous selection
    %parakey is the field name to access the parameters in parafn
    %clusi, parafn, parakey will only be used in 'model' mode
    
    
    
    global camelotpara
    
    %load dataindex => datai
    if ~exist(sprintf('%sdataindex.mat',camelotpara.dataset), 'file')
        error('Cannot find %sdataindex.mat under current directory', camelotpara.dataset);
    end
    load(sprintf('%sdataindex.mat', camelotpara.dataset));  
    
    if ~isempty(camelotpara)
        btthres = camelotpara.btthres;
        savebt = camelotpara.savebt;
        clear camelotpara
    else
        clear global camelotpara
        btthres = 0.5;
        savebt = 1;
    end
    
    if nargin < 5, clusi = -1; end
    if strcmp(mode,'model') && nargin < 7
        if nargin < 6
            parafn = sprintf('%s_%s_paras.mat',dataset,algo);
        end
        if clusi == -1 %use global para for all conditions
            parakey = sprintf('%s_001',strrep(fset,'.',''));
        else
            parakey = sprintf('%s_K%d_001',fset,clusi);
        end
    end
    
    
    
    para.mode = mode;
    para.algo = algo;
    para.fset = fset;

    if strcmp(mode, 'para')    
        if strcmp(algo, 'lasso')
            para.L1 = [0.05 0.1:0.1:20];
            para.lambda = 0;
        elseif strcmp(algo, 'elastic')
            para.L1 = [0.05 0.1:0.1:20];
            %lambda starts from 0: lasso solution            
            para.lambda = [0 0.001:0.001:0.005 0.01 0.05 0.1:0.1:2];            
        end
        para.cv = datai.paracv;
        para.di = datai.paradi;
    elseif strcmp(mode, 'model')        
        if ischar(parafn) 
            parastruct = load(parafn);
            tmp = [parastruct.(parakey).L1 parastruct.(parakey).lambda];
        else
            tmp = parafn;
        end
        switch algo
            case 'lasso'                
                para.L1 = tmp(1);
                para.lambda = 0; %dummy
            case 'elastic'                
                para.L1 = tmp(1);
                para.lambda = tmp(2);
        end     
        para.cv = datai.cv;
        para.bt = datai.bt;
        para.di = datai.di;
        %default
        para.btthre = btthres;
        para.savebt = savebt;
    end
end