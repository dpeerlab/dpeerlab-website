function [trainErrAvg, trainErr, beta, residual] = singOlsRegmtx(x, y)
    %x, y: training entries and targets
    %y: #sample * 1, a column vector
    %x: #sample * #feature
    %
    %trainErrAvg: a column (size top N features), MSE of each feature
    %trainErr: matrix top_N * #trainidx
    %
       

    
    [nTrainSamples, nFeatures] = size(x);
            
    xsqsum = sum(x.^2)'; %column            
    xty = x'*y;

    beta = (xty) ./ (xsqsum); %column
     
    % #sample * #feature

    trainErr = sum(y.^2) + (beta.^2).*xsqsum - 2*beta.*xty;
    residual = repmat(y,1,nFeatures) - repmat(beta',nTrainSamples,1).*x;
    trainErrAvg = trainErr / nTrainSamples;
end