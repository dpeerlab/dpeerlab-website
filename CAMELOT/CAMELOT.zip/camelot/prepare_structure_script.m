
%This script allows users to create the main data structures needed for
%camelot_main.m.
%
%Please note that missing values are currently not supported. If there is
%any missing values, please impute the missing values before prepare the
%data structures.
%
%Users need to have the following files. This script will only process #1-3
%and #5 (if specified). For gene location and conservation information,
%users will need to build their own matlab file.
%
%1. phenotype: Tab-delimited. The file should have (#traits + 1) rows and
%   (#samples + 1) columns, with the first row specifying sample names and 
%   the first column should the names for the traits. 
%   See example: sample.phenotype.txt 
%
%2. genotype: Tab-delimited. Same format as phenotype, but with genotype
%   data. However, the name of the markers should follow the format
%   'M(chromosome number)_start_end' so that camelot can process the
%   locatino of the marker. For example, 'M1_100_150' indicates this is a
%   marker meant to probe the genotype across the coordinate 100~150 on
%   chromosome 1. Example: sample.genotype.txt.
%
%3. gene expression: Tab-delimited. Similar format as phenotype, except the
%   first column should gene ID (or systematic symbols) and the second
%   column should be gene symbol. Example: sample.expression.txt.
%
%4. gene location information: Users have to prepare their own gene
%   location information. This package includes an file (SGD.mat) 
%   containing genomic location of genes for S. cerevisiae (source: 
%   http://www.yeastgenome.org). Users should build the file again if they 
%   want updated information.
%
%(the followings are optional files):
%5. regulator list: A list of genes that are potential regulators of
%   interest. The file should contain the gene ID (separeted by line) of 
%   these regulators. When this list is available, users can use 'R' for
%   the feature set. Example: sample.regulator.txt.
%
%6. conservation information: A file that contains conservation score of
%   proteins among species. Example: consv.mat.
%

%replace these file names with your files
pheno = 'sampledata/sample.phenotype.txt';
geno = 'sampledata/sample.genotype.txt';
exp = 'sampledata/sample.expression.txt';
reg = 'sampledata/sample.regulator.txt';

saveas_data = 'datasample.mat';
saveas_exp = 'expsample.mat';
saveas_marker = 'markersample.mat';

t = parseText(pheno, 'ncolname',1, 'nrowname', 1, 'numeric', true);
datastruct.phenotype = t.text;
datastruct.sample = t.colname(2:end);
datastruct.conds = t.rowname;
t = parseText(geno, 'ncolname', 1, 'nrowname', 1, 'numeric', true);
i = strIndexQuery(t.colname(2:end), datastruct.sample);
if nnz(i==-1) > 1
    error('some samples in the phenotype file can not be found in the genotype file');
end
datastruct.genotype = t.text(:,i);
datastruct.markers = t.rowname;
t = parseText(exp, 'ncolname', 1, 'nrowname', 2, 'numeric', true);
i = strIndexQuery(t.colname(3:end), datastruct.sample);
if nnz(i==-1) > 1
    error('some samples in the phenotype file can not be found in the expression file');
end
datastruct.expression = t.text(:,i);
datastruct.geneid = t.rowname(:,1);
datastruct.genename = t.rowname(:,2);

expdatastruct.phenotype = datastruct.expression;
expdatastruct.conds = datastruct.geneid;
expdatastruct.sample = datastruct.sample;
expdatastruct.genotype = datastruct.genotype;
expdatastruct.markers = datastruct.markers;

markerstruct.sample = datastruct.sample;
markerstruct.impute_dist = datastruct.genotype; %should change the field name if specify 'zoom_markerset' in camelot_main.m
loc = cellfun(@(x) textscan(strrep(x,'M',''), '%d', 'delimiter', '_'), datastruct.markers);
markerstruct.chrm = cellfun(@(x) double(x(1)), loc);
markerstruct.pos = cellfun(@(x) double(ceil(mean(x(2:3)))), loc);

if ~isempty(reg)
    t = parseText(reg, 'ncolname', 0, 'nrowname', 1);
    i = strIndexQuery(datastruct.geneid, t.rowname);
    datastruct.regulators = i(i~=-1);
end
clear t i loc reg pheno exp geno

%You can specify the file names to save these structures
save(saveas_data, 'datastruct');
save(saveas_exp, 'expdatastruct');
save(saveas_marker, 'markerstruct');
