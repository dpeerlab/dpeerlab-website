function [R2 mse p1] = QTLinkage(trait, genotype, si, ei)
    %trait: #observation * #trait; or 'dataset'
    %genotype: #observation * #locus; ignored when trait is dataset
    %si: start condition in trait
    %ei: end condition in trait
    %
    %return:
    %R2: R2 statistics
    %mse: mean squared error
    %p1: H0: if coefficient of a locus is 0
    %
        
    if ischar(trait)        
        s = loadData(trait);
        trait = s.phenotype';
        genotype = s.genotype';
        clear s
    end
    
    [nsample ntrait] = size(trait);
    [nobs nlocus] = size(genotype);
    if nsample ~= nobs
        error('different sample size in trait and genotype\n');
    end
    
    if nargin < 3, si = 1; end
    if nargin < 4, ei = ntrait; end

    ncondRun = ei-si+1;
    fprintf('running QTL for %d traits (%d~%d) with %d loci\n',...
        ncondRun, si, ei, nlocus);
        
    t = cputime();

    R2 = NaN(ncondRun, nlocus);
    mse = NaN(ncondRun, nlocus);
    p1 = NaN(ncondRun, nlocus);

    trait = zeromean_univar_normalization(trait')';

    %fast version, approx, but diff is very small
    %BUT, x, y have to be standardized
    for ti = si:ei
        vi = ~isnan(trait(:,ti));
        X = zeromean_univar_normalization(genotype(vi,:)')';
        y = trait(vi,ti);
        beta = (X' * (y)) ./ (sum(X.^2)'); %column
        nu = sum(vi)-2;
        p = 1;
        yhat = repmat(beta',sum(vi),1).*X; %nsample x nlocus
        ess = sum((yhat-repmat(y,1,nlocus)).^2); %row
        tss = sum((y-mean(y)).^2); %scalar
        rss = sum((yhat-mean(y)).^2); %row %rss and ess "names" should be swapped
        s2 = ess/nu; %row
        F = rss/p./s2; %row
        p1(ti-si+1,:) = 1 - fcdf(F,1,nu); %row
        mse(ti-si+1,:) = ess/sum(vi);
        R2(ti-si+1,:) =  rss./tss;
    end

    fprintf('time: %g\n',cputime()-t);       
    
end

                    
    

