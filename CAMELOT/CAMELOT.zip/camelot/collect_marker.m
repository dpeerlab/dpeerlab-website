function markers = collect_marker(dataset, varargin)
    % Collect all markers that are linked to the phenotype from different
    % methods
    %
    % dataset: name of the dataset
    % options:
    %   algo: algorithms that were used to detect linkages; cell array; can
    %       be 'lasso', 'elastic' and/or 'QTL' (linear regression or ranksum
    %       test, depending on how the method was implemented)
    %   doset: collect markers from regression models that were built with "doset"
    %       features; cell array; for example, 'RG' indicates to collect
    %       markers that are in models that were built with
    %       regulator+genotype with 'algo.' Note any doset must contain 'G'
    %       (standing for genotype), since genotype is what's been
    %       collected here
    %
    % return:
    %   a table of markers
    %
    

    
    datastruct = loadData(dataset);

    fset = {'G','RG','EG'};
    para.algo = {'lasso','elastic', 'QTL'};
    para.doset = {'G','RG','EG'};
    para.btthres = 0.5;
    
    para = assignpara(para, varargin{:});

    ncond = length(datastruct.conds);
    mcollection = cell(ncond,1); %each cell is a list of markers

    for condi = 1:ncond
        mcollection{condi} = cell(0,2);
    end
    
    ifqtl = false;
    
    %lasso, elastic
    for ai = 1:length(para.algo)    
        if strcmpi(para.algo{ai}, 'qtl')
            ifqtl = true;
            continue; 
        end
        m = load(sprintf('%s_%s_model',dataset,para.algo{ai}));
        for fi = 1:length(fset)
            if ~ismember(fset{fi}, para.doset)
                continue
            end
            if isempty(strfind(fset{fi}, 'G')) %double check
                continue
            end
            indicator = false(1, length(para.algo)*length(para.doset)+1); 
            indicator((ai-1)*length(fset)+fi+1) = true;
            sub = m.(sprintf('%s_001',fset{fi}));
            data = dataPrepare(datastruct,fset{fi});

            for condi = 1:ncond            
                if ~isempty(sub{condi})
                    i = intersect(data.G, find(sub{condi}.btratio >= para.btthres));
                    markers = data.xname(i);
                    [tmp mci mi] = intersect(mcollection{condi}(:,1), markers);
                    for tmpi = 1:length(mci)
                        mcollection{condi}{mci(tmpi),2} = ...
                            mcollection{condi}{mci(tmpi),2} | indicator;
                    end
                    for tmpi = setdiff(1:length(markers),mi) %the rest of markers
                        mcollection{condi}{end+1,1} = markers{tmpi};
                        mcollection{condi}{end,2} = indicator;
                    end
                end
            end
        end
        clear m 
    end

    %QTL
    if ifqtl
        indicator = false(1, length(para.algo)*length(para.doset)+1);
        indicator(1) = true;
        qcut = 0.05;
        m = load(sprintf('%s_QTL', dataset));
        [q pcut] = FDR(reshape(m.p1, numel(m.p1), 1), qcut);
        mimtx = m.p1 <= pcut;
        for condi = 1:ncond
            markers = datastruct.markers(mimtx(condi,:));
            [tmp mci mi] = intersect(mcollection{condi}(:,1), markers);
            for tmpi = 1:length(mci)
                mcollection{condi}{mci(tmpi),2} = ...
                    mcollection{condi}{mci(tmpi),2} | indicator;
            end
            for tmpi = setdiff(1:length(markers),mi) %the rest of markers
                mcollection{condi}{end+1,1} = markers{tmpi};
                mcollection{condi}{end,2} = indicator;
            end
        end
    end
    
    %sort markers for each condition
    for condi = 1:ncond
        [tmp si] = sort(mcollection{condi}(:,1));
        mcollection{condi} = mcollection{condi}(si,:);
    end
    markers = mcollection;

end

