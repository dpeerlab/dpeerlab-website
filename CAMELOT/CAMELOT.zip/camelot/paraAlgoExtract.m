function [para1, para2, parastr] = paraAlgoExtract(para)
    %para1 can be processed as a vector by algorithm
    %para2 can only be used as a scalar (thus needs a loop if multiple)
    switch para.algo        
        case {'lasso', 'elastic'}
            para1 = para.L1;
            para2 = para.lambda;
            parastr = {'L1', 'lambda'};
    end
end