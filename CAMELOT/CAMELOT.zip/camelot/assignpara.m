function para = assignpara(para, varargin)
    %assign values to the existing fields of para
    %error if no such field in para
    %
    
    for i = 1:2:length(varargin)
        if isfield(para, varargin{i})
            para.(varargin{i}) = varargin{i+1};
        else
            error('Unknown option %s',varargin{i});
        end
    end