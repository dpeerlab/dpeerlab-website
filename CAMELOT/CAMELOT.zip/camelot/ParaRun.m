function ParaRun(dataset, algo, fset, clusi, runseed, nrun, fnhead)

    warning off all
        
    if nargin < 7, fnhead = ''; end
    
    datastruct = loadData(dataset);
    
    fprintf('set: %s, method: %s, features: %s, runs: %d/%d\n',...
        dataset, algo, fset, runseed, nrun);
    
    para = paraPrepare(dataset, 'para', algo, fset);
    %chop up lambda or the second parameters because the 2nd one is looped
    %in modeling.m; this is for parallel computing on clusters
    para = choppara(para, runseed, nrun);

    clusfield = 'kgi';

    %get growth in the cluster
    data = dataPrepare(datastruct, fset, clusi, clusfield);    
    
    res = modeling(data.x', data.y', para);
    
    varstr = fset;
    
    %running on a cluster of data; for parameter selection
    if clusi ~= -1
        varstr = sprintf('%s_K%d',varstr,clusi); 
    end

    varstr = sprintf('%s_%03d',varstr, runseed);    
    eval(sprintf('%s=res;',varstr));

    fname = sprintf('%s_%s_paras.mat',dataset,algo);

    fname = [fnhead fname];
    if exist(fname, 'file')
        save(fname, varstr, '-append');
    else
        save(fname, varstr);
    end
end

function [newpara] = choppara(para, runseed, nrun)
    newpara = para;
    switch para.algo
        case 'lasso'
            chop = 'L1';
        case 'elastic'
            chop = 'lambda';
    end        
    n = length(para.(chop));
    tmp = para.(chop);
    runtag = mod(n,nrun);
    bigchunk = ceil(n/nrun);
    smallchunk = floor(n/nrun);
    if runseed <= runtag
        tmp = tmp((runseed-1)*bigchunk+1:(runseed)*bigchunk);
    else
        tmp = tmp((runseed-1)*smallchunk+runtag+1:runseed*smallchunk+runtag);
    end
    newpara.(chop) = tmp;
end