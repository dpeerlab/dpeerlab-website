function RLtb = prepareRLtb(dataset)
% read LRPtb structure
% collect all R that are inspected and all L that link to them

s = load(sprintf('%s_LRPtb',dataset));
R = [];
L = {};
ncond = length(s.LRPtb.cond);
for i = 1:ncond
    sub = s.LRPtb.structure(i,:); %{mi}, {ri}
    for j = 1:size(sub{1},1) % #loci
        for ri = sub{2}{j}
            if ~ismember(ri,R)
                R = [R; ri];
                L = [L; sub{1}(j)];
            else
                iInR = find(R==ri);
                L{iInR} = unique([L{iInR} sub{1}{j}]);
            end
        end
    end
end
[sR si] = sort(R);
sL = L(si);
R = sR;
L = sL;

RLtb.dataset = dataset;
RLtb.yi = R;
RLtb.xi = L;
RLtb.ytype = 'reg'; 
RLtb.xtype = 'marker';


