function [q, pc] = FDR(p, qc)
% qc: q-value control
% p: p-values, a vector
% Benjamini and Hochberg procedure
%
% return:
% q: q-value
% pc: cutoff for p-val corresponding to q
%

    if nargin < 2, qc = 1; end

    [r c] = size(p);
    [sp pi] = sort(p);
    
    if r>c
        k = (1:r)'; m = r;
    else
        k = 1:c;    m = c;
    end
    
    pc = sp(max(find( sp <= qc/m*k )));
    if isempty(pc)
        pc = 0;
    end
    for i = m-1:-1:1
        sp(i) = min(sp(i+1), sp(i)*m/i);
    end
    q = NaN(size(p));
    q(pi) = sp;
end