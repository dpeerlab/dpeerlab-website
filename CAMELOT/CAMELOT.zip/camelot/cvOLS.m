function [mse, pred] = cvOLS(targets, features, cv)

    %linear least square error fitting
    
    [numPhenotypes, numSamples] = size(targets);
    [numFeatures] = size(features,1);
    numFolds = size(cv,1);
    
    pred = NaN(size(targets));
    mse = zeros(numPhenotypes,1);
    
    for pheno = 1 : numPhenotypes
        %filter out NaN
        valid_strain = find(isnan(targets(pheno,:))==0);     
        
        err = NaN(numSamples,1);
        
        for fold = 1 : numFolds
            [trainIndx, testIndx] = training_test_indices (fold,cv);
            %exclude NaN strains
            trainIndx = intersect(valid_strain, trainIndx);
            testIndx = intersect(valid_strain, testIndx);
            
            %scaling here!!!!!
            nrm = targets(pheno,trainIndx)';
            b = mean(nrm);

            scx = features(:,trainIndx)';
            scx = scx - repmat(mean(scx),length(trainIndx),1);
            nrmx = zeros(numFeatures,1);
            for i = 1:numFeatures
                nrmx(i) = norm(scx(:,i));
                scx(:,i) = scx(:,i) / norm(scx(:,i));
            end
            scxt = features(:,testIndx)';
            scxt = scxt - repmat(mean(features(:,trainIndx)'),length(testIndx),1);
            for i = 1:numFeatures
                scxt(:,i) = scxt(:,i) / nrmx(i);
            end
            
            OLSb = regress(nrm-b,scx);
            
            pred(pheno,testIndx) = (scxt*OLSb + b )';
            err(testIndx) = (targets(pheno,testIndx)-pred(pheno,testIndx)) .^ 2;
        end
        mse(pheno) = nanmean(err);
    end
end