function [revisetb mse res pred] = crystalball(dataset, basefset, reffset, varargin)
    %parameters
    if nargin < 2, basefset = 'G'; end %the set we use as base for improvement
    if nargin < 3, reffset = 'RG'; end %the set we use to refer and improve the basefset
    
    para.mergemarkercorthres = 0.7;
    para.mergemarkerindexthres = 10;
    para.btthres = 0.5;   
    para.minbtthres = 0.3;
    para.edgepvalthres = 0.05;
    para.loosemergemarkercorthres = 0.6;
    para.doset = {'R', 'RG'};
    
    para = assignpara(para, varargin{:});
    
    takeunion = true;        
    %data preparation
    datastruct = loadData(dataset);
    
    ncond = length(datastruct.conds);
    basefsetindex = dataPrepare(datastruct, basefset, [], [], true);
    reffsetindex = dataPrepare(datastruct, reffset, [], [], true);

    s = load(sprintf('%s_elastic_model',dataset));
    basemodel = sparse(length(basefsetindex.R)+length(basefsetindex.G),ncond);
    refmodel = sparse(length(reffsetindex.R)+length(reffsetindex.G),ncond);

    for condi = 1:ncond
        basemodel(:,condi) = s.(sprintf('%s_001',basefset)){condi}.btratio;
        refmodel(:,condi) = s.(sprintf('%s_001',reffset)){condi}.btratio;
    end
    clear s
    
    lrpresstruct = getLRPresult(dataset, datastruct, para);
    revisetb = cell(ncond,2); %{gi, mi}
    res.condgroup = cell(3,1); %{midman, E-not-midman, G-only}
    res.actions = cell(ncond,6); %{add_gi, remove_gi, add_mi, remove_mi, cleanout_mi, screenrescue_mi}
    for condi = 1:ncond
       [basegi, basemi] = getGiMi(basefsetindex, find(basemodel(:,condi)>=para.btthres));
       [refgi, refmi] = getGiMi(reffsetindex, find(refmodel(:,condi)>=para.btthres));
       %take union of base and ref
       if takeunion
           basegi = union(basegi, refgi);
           basemi = union(basemi, refmi);
       end
       
       %group condition according to reffset
       if isempty(refgi) %G-only
           res.condgroup{3} = [res.condgroup{3}; condi];
       else % E at least
           condflag = 2; 
           if ~isempty(lrpresstruct.lrpres{condi})
               lrpgi = lrpresstruct.lrpfsetindex.gi(lrpresstruct.lrpres{condi}(:,1));           
               for i = 1:length(refgi)               
                   sig = lrpresstruct.lrpres{condi}(lrpgi==refgi(i),9);
                   if sum(sig==2) || sum(sig==1)
                       condflag = 1;
                       break               
                   end               
               end
           end
           res.condgroup{condflag} = [res.condgroup{condflag}; condi];
       end
       
       %clean out elastic markers first
       oldmi = basemi;
       basemi = bestMarkerSet(basemi, para.mergemarkercorthres, ...
           basemodel(basefsetindex.G,condi), datastruct.genotype, para.mergemarkerindexthres);
       res.actions{condi,5} = setdiff(oldmi, basemi);
       
       %LRP results       
       sub = inoutLRP(condi, lrpresstruct, refgi, basemodel(basefsetindex.G,condi), para.minbtthres);
       res.actions(condi,[1:4 6]) = sub;
       
       %add gi
       basegi = union(basegi, sub{1});
       %remove gi
       basegi = setdiff(basegi, sub{2});
       %remove mi
       basemi = setdiff(basemi, sub{4});
       %add mi
       toaddmi = bestMarkerSet(sub{3}, para.mergemarkercorthres, ...
           basemodel(basefsetindex.G,condi), datastruct.genotype, para.mergemarkerindexthres);
       %compete with elastic markers (which have high priority)
       if ~isempty(toaddmi)
           if isempty(basemi)
               basemi = toaddmi;
           else
               mkcor = corr(datastruct.genotype(basemi,:)',datastruct.genotype(toaddmi,:)');
               for mii = 1:length(toaddmi)
                   preselect = basemi( mkcor(:,mii)>=para.mergemarkercorthres );
                   if isempty(preselect) %no elastic markers are correlated with toaddmi
                       basemi = [basemi; toaddmi(mii)];
                   elseif sum(abs(preselect-toaddmi(mii)) < para.mergemarkerindexthres) ==  0
                       %although correlated with elastic markers, but far away
                       basemi = [basemi; toaddmi(mii)];
                   end
               end
           end
       end
       revisetb(condi,:) = {basegi, basemi};
    end    
    
    data = dataPrepare(datastruct,'AG');
    mse = NaN(ncond,1);
    pred = NaN(size(data.y));
    
    load(sprintf('%sdataindex',dataset))
    warning off
    for condi = 1:ncond
        xi = [revisetb{condi,1}; revisetb{condi,2}+length(datastruct.genename)];
        if ~isempty(xi)
            [mse(condi) pred(condi,:)] = cvOLS(data.y(condi,:),data.x(xi,:),datai.cv);
        end
    end
    warning on
    
    fprintf('base: %s, reference: %s\n',basefset, reffset);
end

function sub = inoutLRP(condi, lrps, preselectgi, mbtratio, minbtthres)
    %preselectgi: indexes of genes whose btratio>=para.btthres in elastic reffset
    %mbtratio: btratio of markers in elastic basefset
    %sub{1}: gi to add
    %sub{2}: gi to remove
    %sub{3}: mi to add
    %sub{4}: mi to remove
    %sub{5}: screenoff rescued mi
    sub = cell(1,5);
    rescue = [];
    norescue = [];
    for i = 1:size(lrps.lrpres{condi},1)
        gi = lrps.lrpfsetindex.gi(lrps.lrpres{condi}(i,1)); %map to gi        
        if ~ismember(gi, preselectgi)
            continue
        end
        if lrps.lrpres{condi}(i,9) == 2 %strong midman
            sub{1} = [sub{1}; gi];
            sub{4} = [sub{4}; lrps.lrpregion{condi}{i}'];
        elseif lrps.lrpres{condi}(i,9) == 1 %regional midman
            sub{1} = [sub{1}; gi]; %it's proxy for some markers
            %sub{2} = [sub{2}; gi];
            sub{4} = [sub{4}; lrps.lrpregion{condi}{i}'];
        else %local or non midman
            %only add those whose btratio >=para.minbtthres
            btratio = mbtratio(lrps.lrpregion{condi}{i});
            if sum(btratio >= minbtthres)
                sub{2} = [sub{2}; gi];
                sub{3} = [sub{3}; lrps.lrpregion{condi}{i}(btratio >= minbtthres)'];
                norescue = [norescue; gi];
            else
                rescue = [rescue; gi];
            end
        end
    end    
    %rescue those genes whose markers are not added at all
    rescue = setdiff(rescue,norescue);
    sub{2} = setdiff(sub{2}, rescue);
    %rescue genes that are marked both 'add' and 'remove'; only has effect
    %if we decide to include regional midman
    sub{2} = setdiff(sub{2}, sub{1});
    %those not in lrp-result should be kept (G->D not significant, but
    %E->D is chosen by elastic)
    sub{1} = setdiff(preselectgi, sub{2});
    %do not add markers marked as 'remove' from other genes
    sub{3} = setdiff(sub{3}, sub{4});
    %check if any marker is ambiguous
    if ~isempty(intersect(sub{3},sub{4}))
        error('markers are marked as "add" and "remove", %d\n',condi);
    end    
end

function lrps = getLRPresult(dataset, datastruct, para)

    %giscope is the gene index in reffset
    lrps.lrpfsetindex = dataPrepare(datastruct, 'A', [], [], true);

    [lrps.lrpres lrps.lrpregion] = tableChain(dataset, sprintf('%s_tritest',dataset), ...
        sprintf('%s_rQTL',dataset), sprintf('%s_LRPtb',dataset), 'texttable', false, ...
        'edgepvalthres', para.edgepvalthres, ...
        'loosemergemarkercorthres', para.loosemergemarkercorthres, ...
        'mergemarkerindexthres', para.mergemarkerindexthres, ...
        'doset', para.doset);%, ...
    %[gi perm_mi RPp RPmse GPp GPmse GRp1 GRp2 sig]; gi in A, mi in datastruct
end

function [gi mi] = getGiMi(fsetindex, regressorindex)
    gi = fsetindex.gi(intersect(fsetindex.R, regressorindex));
    mi = intersect(fsetindex.G, regressorindex) - length(fsetindex.R);
end

function bestmi = bestMarkerSet(currentmi, corthres, btratio, genotype, mithres)
    %btratio: btratio of all markers for a condition
    unionmi = unique(currentmi);
    if length(unionmi) > 1
        regi = mergeMarker(genotype(unionmi,:)',corthres,unionmi, mithres);
    elseif length(unionmi) == 1
        regi = 1;
    else
        regi = [];
    end
    ureg = unique(regi); %unique regions
    bestmi = zeros(length(ureg),1);
    for i = 1:length(ureg)
        tmp = unionmi(regi==ureg(i));
        if max(tmp)-min(tmp) > mithres 
            warning('some merged G are %d marker indexes away\n',max(tmp)-min(tmp));
        end        
        [tmpbtratio tmpi] = max(full(btratio(tmp))); %highest btratio
        bestmi(i) = tmp(tmpi);
    end
end