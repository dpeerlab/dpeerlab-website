function res = zoomwperm(dataset, wlike, zoomtb, runcond, nruns, tosave, varargin)
    
    para.detailmarker = '';
    para.markerset = '';
    
    para = assignpara(para, varargin{:});

    if nargin < 6,
        tosave = '';
    end
    if ~ischar(tosave)
        if ~tosave
            tosave = '';
        else
            tosave = sprintf('%s_zoom',dataset);
        end
    end

    %load data
    datastruct = loadData(dataset);        
    [ncond] = length(datastruct.conds);
    %set up outliers for later use
    if isfield(datastruct, 'outliers')
        for condi = 1:ncond
            datastruct.phenotype(condi, datastruct.outliers{condi}) = NaN;
        end
    end
    
    if ischar(wlike)
        s = load(wlike);
        fd = fieldnames(s);
        weight = s.(fd{1}).weight;
        clear s
    else
        weight = wlike.weight;
    end
    
    %load zoomin table; exclude those without SNPs already
    if ischar(zoomtb)
        zoomtb = load(zoomtb);
        fds = fieldnames(zoomtb);
        zoomtb = zoomtb.(fds{1});
    end
    if length(zoomtb) ~= ncond, error('Inconst conditions and marker sets\n'); end    

    %load markers
    markerdb = load(para.detailmarker);
    fd = fieldnames(markerdb);
    markerdb = markerdb.(fd{1});
    
    probestraini = strIndexQuery(markerdb.sample, datastruct.sample);
    if sum(probestraini==-1) > 0
        error('some strains are not in marker3K\n');
    end
    probegenotype = markerdb.(para.markerset);
    genotype = probegenotype(:, probestraini);
    clear markerdb
            
    t = cputime();    
    
    res = cell(length(runcond),1);
    for i = runcond
        %struct.regi, beta, stat
        if isempty(zoomtb{i})
            continue
        end
        [uri nr uregions] = uniqueRegion(zoomtb{i}(:,4));
        regi = cell2mat(zoomtb{i}(:,1));
        growth = datastruct.phenotype(i,:);
        %growth(datastruct.outliers{i}) = NaN; %setup outliers; set up
        %already

        sub = NaN(size(regi,1),2); %[wlike1+2 pvalue pvaluerank]
        for uli = 1:nr
            rowi = find(uri==uli);            
            %choose the most correlated marker in the region as base genotype
            tmpcor = corr(growth', datastruct.genotype(uregions{uli},:)','rows','pairwise');
            [tmpcor tmpi] = max(abs(tmpcor));                        
            [sub(rowi,2) sub(rowi,1)] = permTest(nruns, -1, 'tailR', ...
                @regLikelihood, true, ...
                datastruct.expression(regi(rowi,1),:)', ...
                genotype(regi(rowi,2),:)', ...
                growth', ...
                datastruct.genotype(uregions{uli}(tmpi),:)', ...
                weight(1:2) ); %weighted version            
        end
        res{find(runcond==i)} = addRank(sub, zoomtb, i);
    end    
    if ~strcmp(tosave, '')
        eval(sprintf('save %s%dK_%03d res',tosave,floor(nruns/1000),runcond(1)));
    end
    fprintf('time: %f\n',cputime()-t);    
end


function [uri nr uregions] = uniqueRegion(regions)
    %regions: cell
    n = length(regions);
    uri = ones(n,1);
    nr = 1;
    uregions = {regions{1}};
    for i = 2:n
        if ~isempty(intersect(regions{i},regions{i-1})) 
            uri(i) = nr;
        else
            nr = nr + 1;
            uregions = [uregions; {regions{i}}];
            uri(i) = nr;
        end
    end
end

function [newsub] = addRank(sub, zoomtb, condi)            
    newsub = sub;    
    if ~isempty(zoomtb{condi})        
        %merge region
        region = {};
        for i = 1:size(zoomtb{condi},1)
            found = false;
            for j = 1:size(region,1)
                if ~isempty(intersect(region{j,1},zoomtb{condi}{i,3})) 
                    found = true;
                    region{j,1} = union(region{j,1},zoomtb{condi}{i,3}); %mindex
                    region{j,2} = [region{j,2} i]; %rowi
                    break;
                end
            end
            if ~found
                region{end+1,1} = zoomtb{condi}{i,3};
                region{end,2} = i;
            end
        end
        for ri = 1:size(region,1)
            %for each region, rank pvalues           
            rowi = region{ri,2};
            pvrank = ranking(newsub(rowi,2),'ascend');
            newsub(rowi,3) = pvrank;
        end
    end    
end

function r = ranking(data, mode)    
    n = length(data);
    uvalue = unique(data);    
    
    tmp = sort(uvalue, mode);
    r = zeros(n,1);
    count = 1;
    for i = 1:length(tmp)
        datai = find(data==tmp(i));
        r(datai) = count;
        count = count + length(datai);
    end
end
