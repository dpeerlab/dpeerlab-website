function [index dist] = gene2ProbeMarker(orf, genelocdb, probeloc)
    %orf: cell, orf x 1
    %genelocdb: genelocdb struct
    %probloc: matrix, probe x 2; the first column is chrm and the second is
    %   position
    %
    %return:
    %   index: index of the closest marker in the probeset
    %   dist: distance to the closest marker for each gene
    %
    
    if ~iscell(orf), orf = {orf}; end
    gi = strIndexQuery(genelocdb.orf, orf);
    if sum(gi==-1)>0
        error('Some orfs are not found in genelocdb.\n');        
    end
    
    norf = length(orf);
    index = NaN(norf, 1);
    dist = NaN(norf, 1);
        
    chrm = unique(genelocdb.loc(gi,1));
    for ci = 1:length(chrm)
        subseti = find(genelocdb.loc(gi,1) == chrm(ci));
        chrmgi = gi(genelocdb.loc(gi,1) == chrm(ci));
        sloc = genelocdb.loc(chrmgi,2);
        eloc = genelocdb.loc(chrmgi,3);
        chrmpi = find(probeloc(:,1) == chrm(ci));
        ploc = probeloc(chrmpi,2)';
        
        sdistmtx = repmat(sloc,1,length(ploc)) - repmat(ploc,length(sloc),1);
        edistmtx = repmat(eloc,1,length(ploc)) - repmat(ploc,length(eloc),1);
        distmtx = sdistmtx .* edistmtx; %gene x probe
        
        mask = (sum(distmtx<=0, 2)>0)'; %mark genes that have probe(s) inside
        
        btwmarkerSi = find(mask==0); %find closet to the end of genes
        mindistmtx = min(abs(sdistmtx(btwmarkerSi,:)), abs(edistmtx(btwmarkerSi,:)));
        orfi = subseti(btwmarkerSi);
        [dist(orfi) pi] = min(mindistmtx,[],2);
        index(orfi) = chrmpi(pi);
        
        inmarkerSi = find(mask);
        strand = genelocdb.strand(chrmgi(inmarkerSi));
        Wstrand = ~cellfun('isempty',strfind(strand,'W'));        
        for i = inmarkerSi %find closest to TSS
            pi = find(distmtx(i,:)<=0);
            if Wstrand( inmarkerSi == i )
                [dist(subseti(i)) iInpi] = min(abs(sdistmtx(i,pi)));
                index(subseti(i)) = chrmpi(pi(iInpi));
            else
                [dist(subseti(i)) iInpi] = min(abs(edistmtx(i,pi)));
                index(subseti(i)) = chrmpi(pi(iInpi));
            end
        end
    end
    