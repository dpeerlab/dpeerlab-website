function ModelRun(dataset, algo, fset, condsi, condei, fnhead, parafn)    
    %dataset: {'noel','ethan','syn','reg','erin','ethanol'}
    %algo: {'elastic','lasso'}
    %fset: {'R','G','RG', 'D','DG', 'E', 'EG'}
    %condsi, condei: start and end condition indexes; if condsi='clus',
    %   condei = cluster index
    %

    warning off all      

    clusfield = 'kgi';
         
    datastruct = loadData(dataset);
    
    %overwrite condsi and condei
    if ischar(condsi) %only support cluster mode; for parameter selection
        if strcmp(condsi, 'clus')
            runconds = find(datastruct.(clusfield)==condei)';
            fprintf('set: %s, method: %s, features: %s, clus: %d\n', ...
                dataset, algo, fset, condei);
        else
            error('Unknown option for condsi: %s\n',condsi);
        end
    else
        runconds = condsi:condei;
        fprintf('set: %s, method: %s, features: %s, condi: %d-%d\n', ...
            dataset, algo, fset, condsi, condei);
    end

    %prepare data
    data = dataPrepare(datastruct, fset);    
        
    %loop over condition here
    res = cell(length(runconds),1);
    for si = runconds        
        %load para according to the cluster index
        para = paraPrepare(dataset, 'model', algo, fset, ...
            datastruct.(clusfield)(si), parafn);
        
        X = data.x;
        
        %double check invalid condition
        if (sum(isnan(data.y(si,:))) == length(data.y(si,:)))          
            fprintf('invalid condition: %d, skipped\n',si);
            continue
        end
        
        res{find(runconds==si)} = modeling(X', data.y(si,:)', para);
    end

    if ~ischar(condsi)
        varstr = sprintf('%s_%03d', fset, condsi);

        eval(sprintf('%s=res;', varstr));
        fname = sprintf('%s_%s_%s_%03d', dataset, algo, fset, condsi);

    else %clus mode
        varstr = sprintf('%s_clus_%02d', fset, condei);

        eval(sprintf('%s=res;', varstr));
        fname = sprintf('%s_%s_%s_clus_%03d', dataset, algo, fset, condei);

    end

    fname = [fnhead fname];
    save(fname, varstr);
    
end
