function [finalres tb] = gatherModel(fheader, fdir)    
    %merge data from mat files generated from ModelRun
    %don't use '-append' because matlab can't control concurrent
    %mat-writing
    
    if nargin < 2, fdir = ''; end
    
    %merge data from all mat files with header as fheader
    d = dir([fdir '*.mat']);
    fnset = {};
    for i = 1:length(d)
        floc = strfind(d(i).name, fheader);
        if ~isempty(floc)
            if floc(1) == 1
                fnset = [fnset; d(i).name];
            end
        end
    end
    
    fntoken = parsefn(fnset{1},'');
    if isfield(fntoken, 'clusi') %clus mode
        datastruct = loadData(fntoken.set);
        ncond = length(datastruct.conds);
    else
        datastruct = '';
        ncond = 0;
    end
 
    if isempty(fntoken.fold)
        fsettb = {};
        for i = 1:length(fnset)
            %get fsetkey
            fntoken = parsefn(fnset{i}, datastruct);
            found = false;
            for j = 1:size(fsettb,1)
                if strcmp(fsettb{j,1}, fntoken.fset) 
                    fsettb{j, 2} = [fsettb{j,2} fnset{i}];
                    found = true;
                    break
                end
            end
            if ~found
                fsettb(end+1,:) = {fntoken.fset, {fnset{i}} };
            end
        end

        if ncond == 0 %condi mode
            for i = 1:size(fsettb,1)        
                res = extractVar(fsettb{i,2}{1}, fdir);
                for j = 2:length(fsettb{i,2})
                    tmp = extractVar(fsettb{i,2}{j}, fdir);
                    res = [res; tmp];
                end
                varstr = sprintf('%s_001',fsettb{i,1});
                eval(sprintf('finalres.%s = res;',varstr));
            end    
        else %clus mode
            for i = 1:size(fsettb,1)
                res = cell(ncond,1);
                for j = 1:length(fsettb{i,2})
                    fntoken = parsefn(fsettb{i,2}{j}, datastruct);
                    tmp = extractVar(fsettb{i,2}{j}, fdir); %read each file
                    res(fntoken.conds) = tmp;
                end
                varstr = sprintf('%s_001',fsettb{i,1});
                eval(sprintf('finalres.%s = res;',varstr));
            end
        end
        tb = fsettb;
    else
        nfold = 0;
        for i = 1:length(fnset)
            fntoken = parsefn(fnset{i}, datastruct);
            nfold = max([nfold, fntoken.fold]);
        end
        foldtb = cell(nfold,1);
        for i = 1:length(fnset)
            %get fsetkey
            fntoken = parsefn(fnset{i}, datastruct);
            found = false;
            if isempty(foldtb{fntoken.fold})
                foldtb{fntoken.fold} = {};
            end
            for j = 1:size(foldtb{fntoken.fold},1)
                if strcmp(foldtb{fntoken.fold}{j,1}, fntoken.fset) 
                    foldtb{fntoken.fold}{j, 2} = [foldtb{fntoken.fold}{j,2} fnset{i}];
                    found = true;
                    break
                end
            end
            if ~found
                foldtb{fntoken.fold}(end+1,:) = {fntoken.fset, {fnset{i}} };
            end
        end

        if ncond == 0 %condi mode
            error('invalid');  
        else %clus mode
            for fold = 1:nfold
                for i = 1:size(foldtb{fold},1)
                    res = cell(ncond,1);
                    for j = 1:length(foldtb{fold}{i,2})
                        fntoken = parsefn(foldtb{fold}{i,2}{j}, datastruct);
                        tmp = extractVar(foldtb{fold}{i,2}{j}, fdir); %read each file
                        res(fntoken.conds) = tmp;
                    end
                    varstr = sprintf('%s_001',foldtb{fold}{i,1});
                    eval(sprintf('finalres.fold%02d.%s = res;',fold,varstr));
                end
            end
        end
        tb = foldtb;
    end
end

function res = extractVar(fn, fdir)
    try
        s = load([fdir fn]);
    catch
        fprintf('%s\n',fn);
        res = 'NA';
        return
    end
    name = fieldnames(s);
    res = s.(name{1});
end

function res = parsefn(fn, datastruct)
    fn = strrep(fn,'.mat','');
    [res.set t] = strtok(fn,'_');
    [res.algo t] = strtok(t,'_');
    [res.fset t] = strtok(t,'_');
    res.fset = strrep(res.fset, '.', '');
    if ~isempty(strfind(t, 'clus')) %clus mode
        [tmp t] = strtok(t, '_');
        if ~strcmp(tmp,'clus')
            [tmp t] = strtok(t, '_'); %strip clus
        end
        [clusistr t] = strtok(t,'_');
        res.clusi = str2double(clusistr);
        if isstruct(datastruct)
            res.conds = find(datastruct.kgi==res.clusi);
        end
    else
        [tmp t] = strtok(t, '_');
        if isempty(t) %the last token, should be condi
            res.condi = str2double(tmp);
        else
            res.specx = tmp;
            res.condi = str2double(strtok(t,'_'));
        end
    end
    if ~isempty(strfind(t, 'fold'))
        [tmp t] = strtok(t, '_');
        res.fold = str2double(strtok(t,'_'));
    else
        res.fold = [];
    end
end